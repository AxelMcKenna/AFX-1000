E25 RAIL-DISCONNECT PLACEMENT / A11 HOUSING / SOURCE-HARNESS REVIEW

Higher-headroom standalone source base: 7abd80c928c1402ec783bfe170113efaa957e3f7.
Separate from the main checkout's B1 budget profile and A08 edits.
No commit, merge, ordering, flashing, fabrication or physical testing included.

E25 places all 164 original E17/E21 parts on a relieved 156 x 45.25 x 1.6mm,
six-layer candidate. Four M2 fixing holes are retained in the new design.
Original pin/value contracts, fourteen grouped MOSFET footprints and negative
capacitor polarities are checked. KiCad 10.0.7 reports zero all-severity
nonrouting DRC/parity issues and 365 real open connections. E25 has no copper.

A11 adds this board at (8,108.5,4.6)mm below the existing front controls.
PCB corner reliefs avoid the case bosses. C20/C24 avoid the control supports.
Capacitor cylinders use maximum Panasonic FR-A diameter/length plus declared
seating/board allowances. A local guide/inner-ledge cut preserves 2mm of vent
air above C24 while the external chassis, lid and controls remain unchanged.
Native checks pass for all 54 printable solids / 117 copies, full button and
lever sweeps and eight collision checks, including 0.25mm disconnect body,
lead, fixing-head and vent reserves. Minimum E25 allocated floor gap is 0.30mm
with THT tails/solder <=1.5mm. This is conditional geometric fit, not a physical
assembly, vent-operation, electrical, thermal or protection qualification.

All 150 electronics/tooling regressions and 23 CAD integration regressions pass.
The eleven source-side power/AUX/run harness pins match actual PCB lands,
exported netlists and A11 board datums. Distances are straight-line lower bounds,
not cut lengths. Connectors, contacts, production current ratings and wire gauges
are unselected. Protected-load/front-control/display wiring remains unfinished.

The provisional 0.823mm2 (about18AWG) wire trial FAILS both remaining 5V loss
budgets: about2.181mV versus2.170mV on analog5V and11.898mV versus2.788mV on
digital5V. This is before contacts, temperature or routing detours. Revise the
power distribution/regulation design before releasing a harness. Existing rail
targets are unchanged; failed screens and unreleased flags remain in the data.

The main supply and A10 native evidence remain unchanged and source-current:
2,600 segments,285 vias,322 checked paths,seven filled planes,zero native DRC,
parity or open items. Root navigation hashes were refreshed to link this work.
A09/A10 sources and all prior review archives remain preserved.

The A11 nested print pack contains CAD, meshes, quantity-correct 3MF, inventories,
native records and reviews, the UNROUTED E25 PCB, the UNQUALIFIED main PCB and
source-harness data. The A10 pack is retained for the earlier source-current
mechanical evidence. Native PCB PNGs are included; bottom views are mirrored.
updated/ plus source.patch reconstruct all changed sources against the base.
The patch passed git apply --check against fresh affected base files. Manifest
hashes and ZIP CRC checks passed. Prior archives remain immutable.

Reproduce with the matching KiCad/Python/OpenSCAD environment:
 python3 -m hardware.electronics.rail_disconnect.placement.generate --kicad-cli /path/to/kicad-cli
 python3 -m hardware.electronics.rail_disconnect.placement.check --kicad-cli /path/to/kicad-cli
 python3 -m hardware.wiring.power
 python3 hardware/cad/a11/build.py --openscad /path/to/openscad
 python3 -m hardware.cad.a11.verify
 python3 -m unittest discover -s tests/tooling -v
 python3 -m unittest discover -s tests -p 'a*_integration_tests.py' -v
Generation invalidates verification. Spatial changes require a new native CAD
build. A11 direct provenance was refreshed after checking that all SCAD bytes
and the complete spatial packet were unchanged from its successful native run.

Remaining: E25 routing/current balance/loss, production 5V distribution, other
standalone boards, complete wiring and all powered startup/fault/thermal/EMI,
audio and physical assembly tests. Complete-unit build-ready:false.
