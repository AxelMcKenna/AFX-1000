# E25 independent copper candidate

This package preserves the checked E25 placement, outline, mounting holes, component faces and all pin/net contracts. The original placement and A11 mechanical source remain frozen. Copper is developed here as a separate candidate.

The first routing stage connects all three physical source lands on each of fourteen VSON MOSFETs, all seven back-to-back common-source buses and the two parallel digital source/protected drain banks. Individual source bars use 0.7 mm F.Cu; local common buses use 1.2 mm; the digital source/protected row bridges use 2.0 mm. These dimensions are explicit geometry, not a current, thermal, resistance or switching qualification. They do not repair the existing failed 5 V system loss screens.

The checker independently preserves the entire noncopper placement tree, exports the original schematic pin/value contract, traces actual local F.Cu including interior junctions, and runs KiCad all-severity/all-track/parity checks. The JSON records all real open connections. `pcb_routed` describes native connectivity only; `build_ready` remains false.

```sh
python3 -m hardware.electronics.rail_disconnect.routing.generate
python3 -m hardware.electronics.rail_disconnect.routing.check --kicad-cli /path/to/kicad-cli
```

`generate --complete` attempts six-layer conservative grid routing of the remaining nets. Its masks include all six layers for plated pads and conventional through vias, relief/edge exclusion and keep-outs around SMD pads for via placement. It is a routing aid; generated copper has no approval until fresh independent checks and native DRC pass. Generation removes prior verification. No via-in-pad/capped process, fabrication stackup, copper weight, connector loss or matched parallel-FET current has been qualified.

Remaining work includes rail/logic/ground routing, complete source-to-load resistance and return topology analysis, current sharing and transition behavior, supplier/fabricator land-pattern review, thermal/EMI and all real startup/fault/audio/assembly measurements. No board has been ordered, powered or measured by this package.
