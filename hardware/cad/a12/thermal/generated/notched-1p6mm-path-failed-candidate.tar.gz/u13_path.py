"""Conditional native-copper U13 EP→via→TIM screen; never a junction pass."""

import argparse
import gzip
import json
import math
from pathlib import Path

from .analyze import HEAT, native_heat_and_vias, via_resistance
from .generate import OUT, REPO, ROOT, contact_contains, lands, load, sha


def solve(
    d,
    grid=160,
    copper_um=70,
    tim_gap_mm=1.22,
    contact_c_per_w=0,
    copper_k=385,
    tim_k=6,
    layers=("F.Cu", "In1.Cu", "In2.Cu", "In3.Cu", "In4.Cu", "B.Cu"),
    pcb_path=None,
):
    assert copper_k > 0 and tim_k > 0 and tim_gap_mm > 0 and contact_c_per_w >= 0
    import numpy as np
    from scipy.sparse import lil_matrix
    from scipy.sparse.csgraph import connected_components
    from scipy.sparse.linalg import spsolve

    from hardware.electronics.common.sexpr import children, first, read_sexpr
    from hardware.electronics.output_stage.check_placement import transform

    pcb = (
        Path(pcb_path)
        if pcb_path is not None
        else REPO / "hardware/electronics/power_distribution/p03/power_p03.kicad_pcb"
    )
    tree = read_sexpr(pcb.read_text())
    site = next(s for s in lands(d) if s["refs"] == ["U13"])
    # Convert the metal contact from housing to actual native PCB coordinates.
    gx, gy, w, h = site["metal_global"]
    x0, y0 = gx - 68, gy - 8
    dx, dy = w / grid, h / grid
    xx, yy = np.meshgrid(x0 + (np.arange(grid) + 0.5) * dx, y0 + (np.arange(grid) + 0.5) * dy)
    xy = np.column_stack([xx.ravel(), yy.ravel()])
    sink_mask = contact_contains(site, xy[:, 0] + 68, xy[:, 1] + 8)
    n = grid * grid
    mask = {layer: np.zeros(n, dtype=bool) for layer in layers}
    z = 0.0
    centres = {}
    thickness = {}
    for row in children(first(first(tree, "setup"), "stackup"), "layer"):
        value = float(first(row, "thickness")[1])
        if str(row[1]) in layers:
            centres[str(row[1])] = z + value / 2
            thickness[str(row[1])] = value
        z += value
    assert abs(z - 1.6) < 1e-6 and set(centres) == set(layers)

    def polygon_contains(poly):
        inside = np.zeros(n, dtype=bool)
        for a, b in zip(poly, poly[1:] + poly[:1]):
            if a[1] == b[1]:
                continue
            inside ^= ((a[1] > xy[:, 1]) != (b[1] > xy[:, 1])) & (
                xy[:, 0] < (b[0] - a[0]) * (xy[:, 1] - a[1]) / (b[1] - a[1]) + a[0]
            )
        return inside

    for zone in children(tree, "zone"):
        if not children(zone, "net") or str(first(zone, "net")[1]).lstrip("/") != "AGND":
            continue
        for fill in children(zone, "filled_polygon"):
            layer = str(first(fill, "layer")[1])
            if layer not in mask:
                continue
            poly = [list(map(float, p[1:3])) for p in children(first(fill, "pts"), "xy")]
            if (
                min(p[0] for p in poly) > x0 + w
                or max(p[0] for p in poly) < x0
                or min(p[1] for p in poly) > y0 + h
                or max(p[1] for p in poly) < y0
            ):
                continue
            mask[layer] |= polygon_contains(poly)
    fp = next(
        f
        for f in children(tree, "footprint")
        if next((p[2] for p in children(f, "property") if p[1] == "Reference"), None) == "U13"
    )
    ep = next(p for p in children(fp, "pad") if str(p[1]) == "11")
    epxy = transform(fp, first(ep, "at")[1:3])
    epw, eph = map(float, first(ep, "size")[1:3])
    epmask = (np.abs(xy[:, 0] - epxy[0]) <= epw / 2) & (np.abs(xy[:, 1] - epxy[1]) <= eph / 2)
    mask["F.Cu"] |= epmask
    _, fields = native_heat_and_vias(d, pcb)
    field = next(s for s in fields if s["id"] == site["id"])
    vias = []
    native_vias = children(tree, "via")
    for via in field["actual_vias_inside_metal_contact"]:
        x, y = via["x_global_mm"] - 68, via["y_global_mm"] - 8
        item = next(v for v in native_vias if math.dist(list(map(float, first(v, "at")[1:3])), [x, y]) < 1e-6)
        outer = float(first(item, "size")[1]) / 2
        inner = via["finished_bore_mm"] / 2
        radius2 = (xy[:, 0] - x) ** 2 + (xy[:, 1] - y) ** 2
        annulus = (radius2 <= outer**2) & (radius2 >= inner**2)
        contacts = np.flatnonzero(annulus)
        assert len(contacts) > 0, "Via annulus unresolved; refine grid"
        for layer in layers:
            mask[layer] |= annulus
            mask[layer] &= radius2 >= inner**2
        vias.append((contacts, via_resistance(drill_mm=via["finished_bore_mm"]) * 385 / copper_k))
    epmask &= mask["F.Cu"]
    active = np.concatenate([mask[layer] for layer in layers])
    indices = np.flatnonzero(active)
    lookup = {int(p): i for i, p in enumerate(indices)}
    matrix = lil_matrix((len(indices), len(indices)))
    q = np.zeros(len(indices))

    def link(p, pp, g):
        a, b = lookup[p], lookup[pp]
        matrix[a, a] += g
        matrix[b, b] += g
        matrix[a, b] -= g
        matrix[b, a] -= g

    # No FR4 or parallel air heat-transfer credit is assumed; actual AGND planes are included.
    area = dx * dy * 1e-6
    via_count = 0
    for layer in range(len(layers)):
        for j in range(grid):
            for i in range(grid):
                p = layer * n + j * grid + i
                if p not in lookup:
                    continue
                for di, dj in ((1, 0), (0, 1)):
                    ii, jj = i + di, j + dj
                    if ii >= grid or jj >= grid:
                        continue
                    pp = layer * n + jj * grid + ii
                    if pp not in lookup:
                        continue
                    link(
                        p,
                        pp,
                        copper_k
                        * (thickness[layers[layer]] / 1000)
                        * (copper_um / 70)
                        * (dy / dx if di else dx / dy),
                    )
                if layer == len(layers) - 1 and sink_mask[p % n]:
                    matrix[lookup[p], lookup[p]] += tim_k * area / (tim_gap_mm / 1000)
    for contacts, r in vias:
        for layer in range(len(layers) - 1):
            fraction = (centres[layers[layer + 1]] - centres[layers[layer]]) / 1.6
            for p in contacts:
                link(int(p) + layer * n, int(p) + (layer + 1) * n, 1 / (r * fraction * len(contacts)))
        via_count += 1
    ep_nodes = [lookup[int(p)] for p in np.flatnonzero(epmask)]
    assert ep_nodes and vias
    q[ep_nodes] = 1 / len(ep_nodes)
    full_matrix = matrix.tocsr()
    _, labels = connected_components(full_matrix, directed=False)
    sink_nodes = [lookup[int(p)] for p in indices if p >= (len(layers) - 1) * n and sink_mask[p % n]]
    grounded_labels = set(int(labels[p]) for p in sink_nodes)
    keep = np.array([int(label) in grounded_labels for label in labels])
    assert float(q[~keep].sum()) < 1e-12, (
        "A powered EP copper island has no declared path to TIM; reject model"
    )
    # Unheated islands with no sink have an undefined absolute temperature and
    # no influence on this path. Remove those blocks; never add fictitious gmin.
    discarded = int((~keep).sum())
    mapping = np.full(len(indices), -1, dtype=int)
    mapping[keep] = np.arange(int(keep.sum()))
    matrix = full_matrix[keep][:, keep]
    q = q[keep]
    ep_nodes = [int(mapping[p]) for p in ep_nodes]
    temperature = spsolve(matrix, q)
    assert np.all(np.isfinite(temperature)), "Disconnected copper grid/convergence failure; do not use result"
    residual = float(np.max(np.abs(matrix.tocsr() @ temperature - q)))
    assert residual < 1e-8
    peak = float(max(temperature[p] for p in ep_nodes))
    mean = float(np.mean(temperature[ep_nodes]))
    land = (
        (d["base"]["thermal_land_top_z"] - d["base"]["plate_top_z"])
        / 1000
        / (167 * site["metal_contact_area_mm2"] * 1e-6)
    )
    total = 3 + peak + land + contact_c_per_w
    power = HEAT["U13"][2]
    required = (85 - 60) / power
    return dict(
        native_pcb_sha256=sha(pcb),
        native_ep=dict(xy_mm=epxy, size_mm=[epw, eph]),
        metal_contact_area_mm2=site["metal_contact_area_mm2"],
        sink_domain_area_raster_mm2=float(sink_mask.sum() * dx * dy),
        contact_relief=site.get("corner_relief"),
        grid=[grid, grid],
        outer_copper_assumed_um=copper_um,
        actual_stack_copper_centres_mm=centres,
        actual_nominal_copper_thickness_mm=thickness,
        included_layers=list(layers),
        actual_filled_copper_grid_area_mm2={k: float(v.sum() * dx * dy) for k, v in mask.items()},
        actual_matching_through_vias=via_count,
        actual_via_centres_inside_ep=sum(
            abs(v["x_global_mm"] - 68 - epxy[0]) <= epw / 2 and abs(v["y_global_mm"] - 8 - epxy[1]) <= eph / 2
            for v in field["actual_vias_inside_metal_contact"]
        ),
        copper_k_assumed_w_per_mk=copper_k,
        tim_k_typical_w_per_mk=tim_k,
        tim_gap_assumed_mm=tim_gap_mm,
        ep_peak_to_land_network_c_per_w=peak,
        ep_mean_to_land_network_c_per_w=mean,
        package_theta_jc_c_per_w=3,
        aluminum_land_axial_c_per_w=land,
        extra_contact_assumed_c_per_w=contact_c_per_w,
        conditional_total_junction_to_base_c_per_w=total,
        power_allocation_w=power,
        conditional_junction_at_60c_base_c=60 + power * total,
        conditional85c_allocation_satisfied_before_uncertainty=60 + power * total <= 85,
        maximum_base_for_85c_junction_before_uncertainty_c=85 - power * total,
        required_total_junction_to_base_at_60c_c_per_w=required,
        remaining_contact_and_parameter_uncertainty_budget_c_per_w=required - (3 + peak + land),
        kcl_residual_w=residual,
        disconnected_zero_heat_copper_cells_excluded=discarded,
        fictitious_sink_or_gmin_added=False,
        solver_converged=True,
        assumptions="Selected native copper sheets discretized from actual saved AGND fills,EP rectangle and matching via nodes. Cell-centre occupancy with each actual via pad annulus represented by lumped vertical barrel conductance distributed across its raster cells; local annular radial spreading and copper-cap conduction are not solved,adiabatic patch edges;non-AGND layers,FR4 and parallel air cooling receive no credit. TIM sinks only beneath bottom copper;mask/contact resistance and package theta uncertainty are not bounded. These are declared scenarios,not guaranteed material minima or a full-board FEA.",
        physical_junction_verified=False,
        thermal_path_qualified=False,
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pcb")
    args = parser.parse_args()
    d = load()
    pcb = (
        Path(args.pcb)
        if args.pcb
        else REPO / "hardware/electronics/power_distribution/p03/power_p03.kicad_pcb"
    )
    start = sha(pcb)
    scenarios = [
        solve(d, grid=160, copper_um=70, tim_gap_mm=gap, contact_c_per_w=contact, pcb_path=pcb)
        for gap, contact in ((1.22, 0), (1.22, 0.8), (1.5, 2))
    ]
    fine = solve(d, grid=320, copper_um=70, tim_gap_mm=1.22, contact_c_per_w=0, pcb_path=pcb)
    material_sensitivity = solve(
        d, grid=160, tim_gap_mm=1.5, contact_c_per_w=2, copper_k=350, tim_k=4, pcb_path=pcb
    )
    assert sha(pcb) == start, "Native copper changed; reject and rerun"
    outer_only = solve(d, grid=160, layers=("F.Cu", "B.Cu"), pcb_path=pcb)
    assert sha(pcb) == start and all(
        r["native_pcb_sha256"] == start for r in scenarios + [fine, outer_only, material_sensitivity]
    ), "Native copper changed during full run; reject and rerun"
    report = dict(
        revision="A12-T01-U13-network",
        scenarios=scenarios,
        finer_grid=fine,
        outer_only_limited_path=outer_only,
        lower_conductivity_illustrative_sensitivity=material_sensitivity,
        illustrative_sensitivity_is_a_manufacturer_bound=False,
        coarse_fine_peak_network_difference_c_per_w=abs(
            fine["ep_peak_to_land_network_c_per_w"] - scenarios[0]["ep_peak_to_land_network_c_per_w"]
        ),
        source_sha256={
            str(p.relative_to(REPO)): sha(p)
            for p in (ROOT / "u13_path.py", ROOT / "design.json", ROOT / "analyze.py")
        },
        native_copper_origin_repo_path="hardware/electronics/power_distribution/p03/power_p03.kicad_pcb",
        native_copper_origin_sha256=start,
        input_snapshot_path=str(pcb),
        contact_spreading_and_parameter_uncertainty_guaranteed=False,
        whole_path_acceptance=dict(
            formula="T_base_upper + P_IC_upper * R_junction_to_base_upper <=85C",
            conservative_ic_power_allocation_w=HEAT["U13"][2],
            manufacturer_guaranteed_tim_k_lower_w_per_mk=None,
            certified_copper_k_and_via_plating_lower_bound=None,
            assembly_contact_resistance_upper_c_per_w=None,
            bounded_package_and_land_spreading_upper_c_per_w=None,
            positive_expanded_temperature_and_power_uncertainty=None,
            bounded_total_path_upper_c_per_w=None,
            missing_bound_inputs_are_not_zero=True,
            guardbanded_85c_project_acceptance=False,
        ),
        physical_tests_performed=0,
        thermal_qualified=False,
    )
    report["source_sha256"][report["native_copper_origin_repo_path"]] = start
    for dependency in (
        "hardware/cad/a12/thermal/generate.py",
        "hardware/electronics/common/sexpr.py",
        "hardware/electronics/output_stage/check_placement.py",
    ):
        report["source_sha256"][dependency] = sha(REPO / dependency)
    snapshot = OUT / "native-inputs" / ("p03-" + start + ".kicad_pcb.gz")
    snapshot.parent.mkdir(exist_ok=True)
    snapshot.write_bytes(gzip.compress(pcb.read_bytes(), mtime=0))
    report["compressed_native_input_evidence"] = str(snapshot.relative_to(REPO))
    (OUT / "u13-path.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
