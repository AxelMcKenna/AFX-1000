"""Protected DIGITAL wire escape study; not a complete output harness.

Two quarter circles leave the actual E28 J4 pads vertically. This separates
the local bend/obstacle problem from the still-unselected receiving termination.
"""

import argparse
import json
import math
import subprocess
from pathlib import Path

from hardware.cad.a12.positive_links.collisions import snapshot
from hardware.cad.a12.thermal.verify import binary_stl
from hardware.electronics.common.sexpr import children, first, read_sexpr
from hardware.electronics.output_stage.check_placement import transform
from hardware.electronics.rail_disconnect.revision28.wire_outputs import WIRE

from ..generate import REPO, sha

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "generated/output-escape"


def box_distance(p, b):
    return math.sqrt(sum(max(b[i + 1] - p[i], 0, p[i] - b[i + 1] - b[i + 4]) ** 2 for i in range(3)))


def cylinder_distance(p, c):
    return math.hypot(
        max(math.hypot(p[0] - c[1], p[1] - c[2]) - c[4] / 2, 0),
        max(c[3] - p[2], 0, p[2] - c[3] - c[5]),
    )


def arc(start, radius, angle, intervals):
    a = math.radians(angle)
    return [
        [
            start[0] + radius * (1 - math.cos(t)) * math.cos(a),
            start[1] + radius * (1 - math.cos(t)) * math.sin(a),
            start[2] + radius * math.sin(t),
        ]
        for t in [math.pi * i / (2 * intervals) for i in range(intervals + 1)]
    ]


def generate(radius=21, angle=-17.3):
    required = WIRE["minimum_bend_radius_mm"] + WIRE["insulation_od_mm"][1] / 2
    if radius < required or not all(math.isfinite(x) for x in [radius, angle]):
        raise ValueError("Quarter-circle radius must exceed the conservative centreline requirement")
    native, data, hashes = snapshot()
    pcb = REPO / "hardware/electronics/rail_disconnect/revision28/rail_disconnect.kicad_pcb"
    tree = read_sexpr(pcb.read_text())
    thickness = float(first(first(tree, "general"), "thickness")[1])
    fp = next(
        f
        for f in children(tree, "footprint")
        if any(p[1:3] == ["Reference", "J4"] for p in children(f, "property"))
    )
    assert first(fp, "layer")[1] == "F.Cu" and "AWG14_Force" in str(fp[1])
    board = next(b for b in native["boards"] if b["id"] == "E28")
    pads = {str(p[1]): p for p in children(fp, "pad")}
    intervals = 600
    rows, paths = [], []
    for number, net in [("1", "5V_DIG"), ("2", "AGND")]:
        pad = pads[number]
        assert str(first(pad, "net")[-1]).lstrip("/") == net
        xy = transform(fp, first(pad, "at")[1:3])
        start = [
            xy[0] - 100 + board["datum"][0],
            xy[1] - 100 + board["datum"][1],
            board["datum"][2] + thickness + 3.1,
        ]
        points = arc(start, radius, angle, intervals)
        paths.append(points)
        rows.append(
            dict(
                pin=number,
                net=net,
                insulation_start_mm=start,
                escape_end_mm=points[-1],
                arc_length_mm=math.pi * radius / 2,
            )
        )
    position, clearance = 0.65, 0.25
    wire_radius = WIRE["insulation_od_mm"][1] / 2 + position
    # Every continuous arc point is within this distance of a sampled centre.
    # The extra reserve makes a clear point-to-solid screen conservative.
    sampling_cover = 2 * radius * math.sin(math.pi / (8 * intervals))
    boxes = [b for b in native["boxes"] if not b[0].startswith("E28_J4")]
    other = [b for b in data["envelopes"] if not b[0].startswith("disconnect_")] + data["port_envelopes"]
    screening_boxes = boxes + other + native["switch_diagnostic_boxes"]
    screening_boxes = [
        b for b in screening_boxes if b[1] < 192 and b[1] + b[4] > 130 and b[2] < 155 and b[2] + b[5] > 90
    ]
    screening_cylinders = [c for c in native["cylinders"] if c[1] + c[4] / 2 > 130 and c[1] - c[4] / 2 < 192]
    closest = []
    for b in screening_boxes:
        gap = (
            min(box_distance(p, b) for path in paths for p in path) - wire_radius - clearance - sampling_cover
        )
        closest.append(dict(obstacle=b[0], conservative_gap_mm=gap))
    for c in screening_cylinders:
        gap = (
            min(cylinder_distance(p, c) for path in paths for p in path)
            - wire_radius
            - clearance
            - sampling_cover
        )
        closest.append(dict(obstacle=c[0], conservative_gap_mm=gap))
    closest.sort(key=lambda r: r["conservative_gap_mm"])
    for p in [
        Path(__file__),
        REPO / "hardware/electronics/rail_disconnect/revision28/wire_outputs.py",
        ROOT.parent / "positive_links/generated/positive-links.stl",
    ]:
        hashes[str(p.relative_to(REPO))] = sha(p)
    report = dict(
        scope="Insulated quarter-circle J4 escapes only; all destination wiring unfinished",
        source_sha256=hashes,
        selected_wire=WIRE,
        radius_mm=radius,
        horizontal_angle_deg=angle,
        required_centerline_radius_mm=required,
        source_insulation_start_above_nominal_face_mm=3.1,
        source_strip_solder_and_forming_approved=False,
        wire_radius_with_position_allocation_mm=wire_radius,
        position_allocation_mm=position,
        clearance_mm=clearance,
        sample_cover_mm=sampling_cover,
        intervals=intervals,
        routes=rows,
        closest_component_screens=closest[:12],
        numerical_component_screen_clear=closest[0]["conservative_gap_mm"] > 0,
        receiving_E19_J1_is_unselected_Header2=True,
        destination_wire_gauge_and_contact_accepted=False,
        complete_output_harness=False,
        physical_fit_verified=False,
        fabrication_released=False,
    )
    OUT.mkdir(exist_ok=True)
    (OUT / "analysis.json").write_text(json.dumps(report, indent=2) + "\n")
    (OUT / "obstacles.json").write_text(json.dumps(dict(native=native, other=data), indent=2) + "\n")
    source = 'include <../../thermal-integration.scad>\ntrial="geometry";\n'
    source += "paths=" + json.dumps([p[::5] for p in paths]) + ";\n"
    source += "boxes=" + json.dumps(boxes + other) + ";\n"
    source += "cylinders=" + json.dumps(native["cylinders"]) + ";\n"
    source += f"radius={wire_radius + 0.005};\n"
    source += """module wire(i,margin=0){for(j=[0:len(paths[i])-2])hull(){translate(paths[i][j])sphere(r=(radius+margin)/pow(cos(180/64),2),$fn=64);translate(paths[i][j+1])sphere(r=(radius+margin)/pow(cos(180/64),2),$fn=64);}}
module wires(margin=0){wire(0,margin);wire(1,margin);}
module electronics(){for(b=boxes)translate([b[1],b[2],b[3]-.2])cube([b[4],b[5],b[6]+.4]);for(c=cylinders)translate([c[1],c[2],c[3]-.2])cylinder(d=c[4]/cos(180/128),h=c[5]+.4,$fn=128);
"""
    for b in native["boards"]:
        source += (
            "translate("
            + json.dumps([*b["datum"][:2], b["datum"][2] - 0.2])
            + ")linear_extrude("
            + str(b["thickness_range_allocation_mm"][1] + 0.4)
            + ")polygon("
            + json.dumps(b["outline_relative_mm"])
            + ");\n"
        )
    for b in data["boards"]:
        if b[0] != "disconnect_carrier":
            source += "board_reserve(" + json.dumps(b) + ");\n"
    source += """}
module hardware(){return_assembly();import("../../positive_links/generated/positive-links.stl");}
module case_parts(){retained_thermal_shell();thermal_controls();thermal_metal_base();lower_shell_fasteners();}
if(trial=="geometry")wires();
if(trial=="electronics_collision")intersection(){wires(.25);electronics();}
if(trial=="case_collision")intersection(){wires(.25);case_parts();}
if(trial=="hardware_collision")intersection(){wires(.25);hardware();}
if(trial=="pair_collision")intersection(){wire(0,.125);wire(1,.125);}
if(trial=="positive_control")intersection(){wires();translate(paths[0][60]-[.1,.1,.1])cube([.2,.2,.2]);}
"""
    # SCAD paths are relative to this generated subdirectory.
    source = source.replace("../../thermal-integration", "../../../thermal-integration").replace(
        "../../positive_links", "../../../positive_links"
    )
    (OUT / "checks.scad").write_text(source)
    assert all(sha(REPO / name) == value for name, value in hashes.items()), "Snapshot changed during capture"
    return report


def verify(executable):
    report = json.loads((OUT / "analysis.json").read_text())
    (OUT / "verification.json").unlink(missing_ok=True)
    evidence_inputs = {
        str(p.relative_to(REPO)): sha(p)
        for p in [OUT / "checks.scad", OUT / "analysis.json", OUT / "obstacles.json"]
    }
    results = {}
    for case in [
        "geometry",
        "electronics_collision",
        "case_collision",
        "hardware_collision",
        "pair_collision",
        "positive_control",
    ]:
        target = OUT / (case + ".stl")
        target.unlink(missing_ok=True)
        cmd = [str(executable), "--hardwarnings", "--backend", "Manifold", "--export-format", "binstl"]
        for name in ["part", "thermal_part", "positive_part"]:
            cmd += ["-D", name + '="output_escape_only"']
        cmd += ["-D", 'trial="' + case + '"', "-o", str(target), str(OUT / "checks.scad")]
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
        log = p.stdout + p.stderr
        (OUT / (case + ".log")).write_text(log)
        empty = p.returncode == 1 and "Current top level object is empty." in log and not target.exists()
        if case.endswith("collision") and empty and not any(x in log for x in ["WARNING", "ERROR"]):
            results[case] = dict(clear=True, empty=True)
        elif (
            p.returncode == 0
            and target.exists()
            and "NoError" in log
            and not any(x in log for x in ["WARNING", "ERROR"])
        ):
            results[case] = dict(clear=not case.endswith("collision"), **binary_stl(target))
            if case == "geometry":
                r = report["wire_radius_with_position_allocation_mm"] + 0.005
                expected = 2 * (math.pi * r * r * math.pi * report["radius_mm"] / 2 + 4 * math.pi * r**3 / 3)
                results[case]["clear"] = math.isclose(results[case]["volume_mm3"], expected, rel_tol=0.03)
            if case == "positive_control":
                results[case]["clear"] = math.isclose(results[case]["volume_mm3"], 0.008, abs_tol=1e-6)
        else:
            results[case] = dict(clear=False, returncode=p.returncode, result="native execution rejected")
        print(case, results[case], flush=True)
    changed = [name for name, value in report["source_sha256"].items() if sha(REPO / name) != value]
    changed += [name for name, value in evidence_inputs.items() if sha(REPO / name) != value]
    result = dict(
        cases=results,
        changed_inputs=changed,
        local_escape_native_clear=all(r["clear"] for r in results.values()) and not changed,
        numerical_component_screen_clear=report["numerical_component_screen_clear"],
        physical_fit_verified=False,
        complete_output_harness=False,
        fabrication_released=False,
        evidence_inputs_sha256=evidence_inputs,
        source_sha256=report["source_sha256"],
        evidence_sha256={
            str(p.relative_to(REPO)): sha(p) for p in OUT.iterdir() if p.suffix in (".stl", ".log")
        },
    )
    (OUT / "verification.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--radius", type=float, default=21)
    parser.add_argument("--angle", type=float, default=-17.3)
    parser.add_argument("--openscad", type=Path)
    args = parser.parse_args()
    r = generate(args.radius, args.angle)
    print("Closest component screen:", r["closest_component_screens"][:2], flush=True)
    if args.openscad:
        result = verify(args.openscad)
        raise SystemExit(
            0 if result["local_escape_native_clear"] and result["numerical_component_screen_clear"] else 1
        )
