# A12 harness development

The input feed now has specific component candidates in `input-feed.json`: MEAN WELL GST60A12-P1J, the retained PJ-102AH jack, JST VHR-2N housings/SVH-41T-P1.1 contacts, and Alpha 5858 AWG16 PTFE wire. Nothing has been purchased, crimped, powered or qualified. The positive 5 V leads and protected-output fanout remain separate unfinished assemblies.

Run `python3 -m hardware.cad.a12.harness.analyze`. The report binds the actual inlet/P03 native connector positions and source files. It rejects a net/pin change or incompatible insulation diameter. The manufacturer PDFs are kept external; their exact hashes and source URLs are recorded rather than redistributing them.

The [adapter specification](https://www.meanwell.com/Upload/PDF/GST60A/GST60A-SPEC.PDF), revision 2026-04-03, specifies 12 V/5 A and measures voltage at the output plug. Its ±3% tolerance already includes setup, line and load regulation. Adding the temperature coefficient over the project's 0–40°C adapter ambient and a conservative full 120 mV peak-to-peak adverse ripple displacement gives a conditional 11.43–12.57 V interval. This does not bound startup or load-step droop. Its cable drop must not be added a second time. The 12.6–16.2 V overvoltage trip range is not an output-peak clamp. P1J's 11 ±0.5 mm plug versus the jack's 9.5 mm insertion depth still requires shoulder, rear-panel and engagement review.

The [Alpha 5858 specification](https://www.alphawire.com/en/products/wire/hook-up-wire/premium/5858) gives insulation diameter 1.8542–2.2098 mm and a 10-diameter bend radius. The maximum requires a 22.098 mm radius; because the source does not identify inner-surface versus centerline radius, the CAD allocation adds one wire radius and requires a 23.2029 mm centerline radius. It fits the [VH nonretainer housing/contact insulation range](https://www.jst.com/wp-content/uploads/2021/08/eVH.pdf), but exceeds the retainer housing's 2.2 mm limit. VHR-2M is not an interchangeable substitution. The selected AWG16 contact is SVH-41T-P1.1; SVH-21T-P1.1 is for smaller conductors. Crimp tooling, this actual wire construction and pull/section inspection still need approval. The connector's +85°C limit includes current-induced temperature rise.

The two native headers reverse the lateral pin order. A straight coplanar two-wire arrangement would cross. `input_route.py` now provides a conditional three-dimensional route for the two individual wires, with opposite vertical lifts at that crossing. It reads the native pin/net positions, checks the actual 0°/180° header orientations and binds the complete case/component snapshot. Reproduce it with `python -m hardware.cad.a12.harness.input_route --openscad /path/to/OpenSCAD`.

The current candidate allocates a wire exit 22 mm along each connector's mating direction and 3.85 mm above the PCB face, with a 0.65 mm isotropic position allowance. These are **unapproved interface requirements**, not manufacturer dimensions. The sampled free spans are approximately 51.5 and 51.0 mm, with minimum nominal centerline radii of 45.5 and 46.8 mm against the conservative 23.2029 mm requirement. The native solids include the maximum insulation diameter, position allowance and conservative tessellation. Five checks require actual wire solids, clear wire-to-wire/case/electronics intersections and a nonempty deliberately colliding witness. The two intended connector housings alone are excluded from the electronics intersection; all other bodies remain. Results are source-bound in `generated/input-route-verification.json`; subsequent PCB, case or route edits require a new check.

A clear allocated envelope does not approve the mated exits, manufactured bend radius, forming fixture, connector service access, retention, strain relief, terminations or the operating harness. No clips or forming fixture are implemented yet. The 100 mm per-conductor limit is an electrical screening maximum, not a frozen wire-cut drawing; the sampled free span excludes the terminated lengths. At that length, catalog nominal DCR plus an assumed copper temperature coefficient gives about 3.625 mΩ per pair at 85°C. DCR is explicitly nominal; it cannot certify the separate 5 mΩ measured-wire allocation. Likewise, four environmental-test contact limits total 80 mΩ and two catalog jack contacts total 60 mΩ, but neither establishes the assembled hot/lifetime resistance.

The older public VH catalog provides the conservative +85°C screen used here. The [current series page](https://www.jst-mfg.com/product/index.php?lang=2&series=262) lists −40 to +105°C; applicability to the selected exact part and process must be reconciled before changing that screen. Individual dimensional drawings/CAD require a manufacturer form with contact details and terms. That form has not been submitted; no exact mated wire-exit tolerance is inferred from the simplified public illustration.

The complete 0.36 Ω feed remains a conditional P03 scenario. Acceptance needs actual plug-to-protected-input voltage/current measurements across the load/temperature corners, uncertainty, connector/fuse heating, crimps/solder/retention, startup/droop, and coordinated overload/fault behavior. No source interval, dimensional fit or resistance calculation changes a physical-release flag.

The protected DIGITAL output now has a separate **rejected local escape study**
in `output_escape.py` and `generated/output-escape/`. It reads actual E28 J4
pad/net identities and the current PCB thickness (1.62 mm), and models the selected
Alpha 3079 AWG14 pair. Its 21 mm quarter-circle centreline radius exceeds the
19.8374 mm conservative requirement. Both curves turn toward housing +X at
−17.3° in XY, beginning 3.1 mm above the nominal board face. Maximum insulation
diameter, 0.65 mm position allocation and 0.25 mm obstacle clearance are included;
termination, forming and strain-relief dimensions remain unapproved.

The numerical body screen includes both native component faces, radial
capacitors and switch lead reserves, with a continuous-arc sampling-cover bound.
The actual six native checks detect required wire geometry and the deliberately
colliding 0.008 mm³ witness. The wires clear one another and the declared
electronics envelopes, but intersect the case/control mechanism by about
5.1203 mm³ and the power-link/return hardware by about 19.7707 mm³. The failed
STLs include their actual collision locations. The command exits nonzero for
this result; it is not an installed route or evidence that every possible route
is impossible.

```sh
python -m hardware.cad.a12.harness.output_escape \
  --openscad /path/to/OpenSCAD
```

The next repair must coordinate the actual wire/termination or supporting
geometry, followed by new body, case, hardware and bend checks. The receiving
E19 J1 is still an unselected two-pin header interface; no complete AWG14 mate,
branch/fanout, cut/strip drawing, electrical loss, assembled-current or lifetime
qualification is inferred from the local escape. Source and native evidence
hashes are recorded with the failed study. Subsequent board changes require a
new binding.

Two separate thin-insulation studies use the current manufacturer
[Alpha 6717 specification](https://www.alphawire.com/disteAPI/SpecPDF/DownloadProductSpecPdf?productPartNumber=6717).
The proposed AWG14 41/30 tinned conductor retains catalog nominal DCR, with
2.4892 mm maximum insulation diameter and a conservative minimum centreline
radius of 13.6906 mm. `output-wire-6717.json` records the reviewed external PDF
hash and conflict with an older ten-diameter specification. Stock applicability,
current/temperature limits and maximum DCR remain unqualified; the BOM is unchanged.
The thin-wire quarter-circle trial still intersects the case by 0.5659 mm³ and
hardware by 0.1102 mm³. A leftward 3D bend with explicit curvature and
integration-error bounds intersects the case by 2.9724 mm³ and hardware by
26.7073 mm³. Both are rejected local routes.

The isolated `proposals/j4-ear/` project moves actual J4 pads to housing
(165.3,137)/(165.3,143) mm, adding a 3.3 × 10 mm PCB extension and 3 mm lands.
`output_port_proposal.py` builds the copied native project. Native KiCad finds
zero ERC, hard DRC and parity issues, but **47 opens and 77 warnings**: one
additional open versus its source. Native semantic comparison confirms only J4
and Edge.Cuts change; the other 254 footprint contracts, zone contracts and stack
match. Connectivity cannot qualify the new force/return access resistance.

`output_port_fit.py` checks the actual extension and solder/lead reserves against
the full assembly. The extension has its expected 56.1000 mm³ volume and clears
the nominal case/hardware, but the new top joint reserve intersects the ANA
return retainer by **14.8688 mm³**. With explicit ±0.2 mm XYZ position allocation
and 0.25 mm clearance, hardware conflict is 27.1463 mm³ and case conflict is
2.3975 mm³. The 0.008 mm³ positive witness is detected. These port-only checks
exclude curved wires. The first rejected 100-file input/evidence packet is
`generated/rejected-j4-ear-a7433d16a956dd8d.tar.gz`, with its hash manifest.

`output_retainer_proposal.py` builds a separate offset-head retainer from the
original STEP geometry. It preserves the lower stem/base attachment, moves the
head 4 mm along the ramp and adds a PEEK arm. Four valid single solids pass STEP
volume roundtrip. Native checks show the nominal joint interference is removed
and component bodies clear. This proposal is **also rejected**: its head meets
the actual return-bar corner (0.2604 mm³) and positive-link support (46.4624 mm³).
The ear's clearance envelope still intersects the stem by 0.1223 mm³ and fails
case clearance. Only the intended coplanar stem/base seating face is excluded
by 0.00001 mm. Stock, strength, creep, shock and manufacturing remain unqualified.

```sh
python -m hardware.cad.a12.harness.output_port_fit --openscad /path/to/OpenSCAD
python -m hardware.cad.a12.harness.output_retainer_proposal
python -m hardware.cad.a12.harness.output_port_fit \
  --offset-retainer --openscad /path/to/OpenSCAD
```

Both fit commands currently must exit nonzero. The operating PCB, return kit and
housing remain unchanged. A coordinated support/PCB/harness repair or more
headroom needs investigation. The retained 38 mm shell is a project dimension;
the original RMX-1000's specified [overall height is 57 mm](https://pioneernz.co.nz/pages/specifications-rmx-1000).
Those scopes differ: the project's external thermal base already adds height,
and knobs/control travel also belong in the complete envelope comparison.
