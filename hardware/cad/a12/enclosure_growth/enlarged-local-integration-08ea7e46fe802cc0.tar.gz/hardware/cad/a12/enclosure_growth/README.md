# Larger enclosure candidate

The owner authorized reasonable enlargement with a 20% space/headroom target.
This separate candidate starts at **334 × 188.4 × 45.6 mm shell dimensions**:
the original width, 20% more depth and 20% more height. Its rectangular floor
area grows 20%, bounding volume 44%, and box surface area 22.014%. Those are
geometric ratios, not usable-volume reserves, temperature margins or cooling
gains. Actual space allocations still need to establish the desired headroom.

![Actual larger shell/lid and reference outer controls](previews/assembly.png)

This is a native CAD render with illustrative colors. It shows reference outer
controls and inherited feet; internal integration and production construction
remain unfinished. `previews/provenance.json` binds the actual rendered solids.

`generate.py` produces actual native shell/lid solids and a reference outer
assembly. It retains the original control XY and rear I/O at Y0. The additional
31.4 mm is the **front strip at Y157–188.4**, initially unallocated. Existing PCB
mounts are reference geometry. The original six lid fasteners remain, preserving
the existing power-board reliefs; three new front positions at Y180.4 support
the larger lid. Their larger-base attachment and assembly details remain open.

Reproduce with:

```sh
.venv/bin/python -m hardware.cad.a12.enclosure_growth.generate \
  --openscad /path/to/OpenSCAD
```

Every native command records explicit depth/height/fastener overrides. Use the
exported `generated/shell.stl` and `generated/lid.stl` to review the actual larger
parts; opening the staged SCAD without its recorded overrides uses inherited
dimensions. `generated/plan.json` and `generated/verification.json` bind the
sources, actual commands, logs and solids.

The first run passes all **eight native blank/envelope cases**. The shell is one
connected surface with zero bad shared-edge incidence and no collapsed binary
triangles. Its actual bounds are 334 × 188.4 × 45.6 mm. The larger lid clears
the shell after a fixed 0.00002 mm numerical separation of its intended seat;
this is not a physical seating-gap or tolerance approval. Nonempty controls
prove the added front floor, taller wall and new front boss exist; an empty
control proves the new pilot bore is open. The outer reference measures
**95.2 mm overall height** with the inherited control/foot envelopes, compared
with the original 87.6 mm. Raw logs/STLs and all source/evidence hashes were
independently checked. These results concern the enclosure blanks and reference
outer envelope only.

The shell has a 2.8 mm wall/floor and a 2 mm lid, as in the reference kit.
The panel moves from Z36 to Z43.6. Control-board height, shaft reach, button
electronics, light guides, supports and the complete wiring must follow a
coherent new interface plan. No unchanged PCB datum or shaft is assumed to
reach the higher panel. The outer reference uses the old feet at their old
positions only to check the dimensional envelope; it does not approve the new
foot spacing, structural stability or thermal base. Conditional thermal work
in `../housing20percent/` is a separate candidate requiring real new metal and
contact geometry.

The panel mount audit in `../panel_mount_audit/` finds that the low E19/E18/E20
stack can retain its current datums: ten pots, switches and panel emitters are
off-board interfaces. Panel-related parts and harnesses still require renewed
fit and engagement checks. The separate `lever_fit.py` moves the fixed-Z lever,
sensor reserves and four posts together by 7.6 mm. All ten native local cases
clear, including full swept travel through the raised lid. The old fixed lever
intersects that lid by 118.603 mm³ and remains a required nonempty control.

The newer `receiver_access.py` candidate uses actual E19 source `2145521e`, a
wider ear and H9 at (182,92.2). All 19 local native cases clear: real PCB material,
post/head/joints, both original and +7.6 mm component reserves, power hardware,
minimum H9 bore and an open-lid Ø6.5 mm tool envelope. The old axis still hits
the unchanged digital link by 11.35085 mm³, while the new axis clears it. This
is a geometric access candidate, not an approved driver, lid-removal sequence,
insert, fastener or structural process. The actual power/ground path between
mounting exclusions widens from 0.7797 to about 4.8012 mm; resistance/ampacity
must be extracted afresh. A separate later candidate adds physical fanout ports;
its additional material and terminations require new checks.

The Trill C3 candidate in `../trill_mount_candidate/` corrects the old 52 × 21 mm
reserve to the actual nominal 53.848 × 21.844 mm native outline. A separate
insulating saddle follows the raised touch backer and preserves its central
aperture; thirteen local native checks clear. The fixed-low/raised-panel map's
two absolute touch-backer Z fields are corrected separately by that candidate's
`PM01-erratum.json`: actual backer base is Z34.6/42.2, with the same 7.6 mm lift.
The immutable original map and its valid translations remain preserved.

The larger-metal-base thermal scenario reduces the source-loaded peak from
95.36–99.51 °C to 86.19–89.93 °C at the retained 35.4315 W/40 °C ambient and
assumed boundaries; the base alone still fails the 60/65 °C screens. Separate
prescribed-isothermal-base plus metal-lid/sidewall scenarios can exceed that
heat load at 65 °C, but sensitivity and unknown installed conditions preclude
a qualified 20% thermal margin. A loaded coupled assembly has not been solved
or measured. Plastic-shell geometry does not receive metal-shell cooling credit.

The 38 mm-shell J4-to-J13 wire pair has a preserved 21-case native geometry
pass. Changed receiving material, added ports and the complete raised control/
Trill assembly need a fresh integrated run even if the two wire endpoints stay
fixed. Structural loads, material/process bounds, EMI, cooling, physical
assembly and fabrication release remain unverified. The frozen baseline and
sealed qualification evidence are unchanged.
