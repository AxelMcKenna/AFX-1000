# Larger enclosure candidate

The owner authorized reasonable enlargement with a 20% space/headroom target.
This separate candidate starts at **334 × 188.4 × 45.6 mm shell dimensions**:
the original width, 20% more depth and 20% more height. Its rectangular floor
area grows 20%, bounding volume 44%, and box surface area 22.014%. Those are
geometric ratios, not usable-volume reserves, temperature margins or cooling
gains. Actual space allocations still need to establish the desired headroom.

`generate.py` produces actual native shell/lid solids and a reference outer
assembly. It retains the original control XY and rear I/O at Y0. The additional
31.4 mm is the **front strip at Y157–188.4**, initially unallocated. Existing PCB
mounts are reference geometry. The original six lid fasteners remain, preserving
the existing power-board reliefs; three new front positions at Y180.4 support
the larger lid. Their larger-base attachment and assembly details remain open.

Reproduce with:

```sh
.venv/bin/python -m hardware.cad.a12.enclosure_growth.generate \
  --openscad /path/to/OpenSCAD
```

Every native command records explicit depth/height/fastener overrides. Use the
exported `generated/shell.stl` and `generated/lid.stl` to review the actual larger
parts; opening the staged SCAD without its recorded overrides uses inherited
dimensions. `generated/plan.json` and `generated/verification.json` bind the
sources, actual commands, logs and solids.

The first run passes all **eight native blank/envelope cases**. The shell is one
connected surface with zero bad shared-edge incidence and no collapsed binary
triangles. Its actual bounds are 334 × 188.4 × 45.6 mm. The larger lid clears
the shell after a fixed 0.00002 mm numerical separation of its intended seat;
this is not a physical seating-gap or tolerance approval. Nonempty controls
prove the added front floor, taller wall and new front boss exist; an empty
control proves the new pilot bore is open. The outer reference measures
**95.2 mm overall height** with the inherited control/foot envelopes, compared
with the original 87.6 mm. Raw logs/STLs and all source/evidence hashes were
independently checked. These results concern the enclosure blanks and reference
outer envelope only.

The shell has a 2.8 mm wall/floor and a 2 mm lid, as in the reference kit.
The panel moves from Z36 to Z43.6. Control-board height, shaft reach, button
electronics, light guides, supports and the complete wiring must follow a
coherent new interface plan. No unchanged PCB datum or shaft is assumed to
reach the higher panel. The outer reference uses the old feet at their old
positions only to check the dimensional envelope; it does not approve the new
foot spacing, structural stability or thermal base. Conditional thermal work
in `../housing20percent/` is a separate candidate requiring real new metal and
contact geometry.

The 38 mm-shell J4-to-J13 wire pair has a preserved 21-case native geometry
pass, but that result cannot qualify changed endpoints. The H9 tool-axis
obstruction by actual digital copper, the receiving-board neck and missing
force/return fanout also require layout or assembly changes; shell growth alone
does not close them. Structural loads, material/process bounds, EMI, cooling,
physical assembly and fabrication release remain unverified. The frozen
baseline and sealed qualification evidence are unchanged.
