include <gauge.scad>
intersection(){expanded()lug();import("native-inputs/AFX-A12-R01-DIG-CAP-SCREW0.stl");}
