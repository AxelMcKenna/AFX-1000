"""Source-bound native collision screens; failures remain reviewable evidence."""

import argparse
import json
import subprocess

from hardware.cad.a12.thermal.verify import binary_stl

from .generate import OUT, REPO, ROOT, sha


def stale_paths(hashes, base):
    return [
        path
        for path, expected in hashes.items()
        if not (base / path).is_file() or sha(base / path) != expected
    ]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--openscad", required=True)
    args = parser.parse_args()
    packet = json.loads((OUT / "obstacles.json").read_text())
    geometry = json.loads((OUT / "geometry.json").read_text())
    stale_before = stale_paths(packet["source_sha256"], REPO) + stale_paths(geometry["source_sha256"], ROOT)
    if stale_before:
        raise ValueError({"refuse_native_check_with_stale_snapshot": stale_before})
    geometry_hashes = {
        str(q.relative_to(REPO)): sha(q)
        for q in OUT.glob("*")
        if q.suffix in (".step", ".stl") and not q.name.startswith("native-")
    }
    checks = {}
    native_input_hashes = {
        str((OUT / "collisions.scad").relative_to(REPO)): sha(OUT / "collisions.scad"),
        **{path: value for path, value in geometry_hashes.items() if path.endswith(".stl")},
    }
    for name in [
        "copper",
        "case_collision",
        "electronics_collision",
        "returns_collision",
        "pair_collision",
        "support_case_collision",
        "support_electronics_collision",
        "support_returns_collision",
        "support_positive_control",
        "positive_control",
    ]:
        target = OUT / ("native-" + name + ".stl")
        target.unlink(missing_ok=True)
        cmd = [args.openscad, "--hardwarnings", "--backend", "Manifold", "--export-format", "binstl"]
        for value in ['part="positive_only"', 'thermal_part="positive_only"', f'positive_part="{name}"']:
            cmd += ["-D", value]
        cmd += ["-o", str(target), str(OUT / "collisions.scad")]
        try:
            run = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
        except subprocess.TimeoutExpired as error:
            log = "Native subprocess exceeded180second budget; rejected without collision inference.\n" + str(
                error
            )
            (OUT / ("native-" + name + ".log")).write_text(log)
            checks[name] = dict(result="native timeout", accepted=False, timeout_seconds=180)
            continue
        log = run.stdout + run.stderr
        (OUT / ("native-" + name + ".log")).write_text(log)
        if run.returncode == 1 and "Current top level object is empty." in log:
            checks[name] = dict(result="empty", volume_mm3=0)
        elif run.returncode == 0 and "NoError" in log and "WARNING" not in log and "ERROR" not in log:
            checks[name] = dict(result="valid native manifold", **binary_stl(target))
        else:
            checks[name] = dict(result="native failure", returncode=run.returncode, log=log)
    failures = [
        name for name, row in checks.items() if name.endswith("collision") and row.get("volume_mm3", 1) > 1e-6
    ]
    positive = all(
        checks[key].get("volume_mm3", 0) > 0.007 for key in ("positive_control", "support_positive_control")
    )
    evidence_hashes = {
        str(q.relative_to(REPO)): sha(q) for q in OUT.glob("native-*") if q.suffix in (".log", ".stl")
    }
    stale = stale_paths(packet["source_sha256"], REPO) + stale_paths(geometry["source_sha256"], ROOT)
    changed_inputs = [path for path, expected in native_input_hashes.items() if sha(REPO / path) != expected]
    report = dict(
        native_checks=checks,
        geometry_sha256=geometry_hashes,
        native_input_sha256=native_input_hashes,
        native_evidence_sha256=evidence_hashes,
        native_inputs_changed_during_run=changed_inputs,
        simulator_version=subprocess.run(
            [args.openscad, "--version"], capture_output=True, text=True
        ).stderr.strip(),
        collision_failures=failures,
        native_failures=[
            key for key, row in checks.items() if row["result"] not in ("empty", "valid native manifold")
        ],
        positive_control_detected=positive,
        stale_sources=stale,
        source_sha256=packet["source_sha256"],
        all_component_mate_heights_approved=False,
        cover_and_restraint_qualified=False,
        electrical_joint_qualified=False,
        physical_fit_verified=False,
        fabrication_released=False,
        selected_for_production=False,
    )
    (OUT / "verification.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
