"""Fresh native both-face board bodies and all inherited A12 obstacles."""

import json

from hardware.cad.a12.generate import build
from hardware.cad.a12.repaired import packet

from .generate import OUT,REPO,ROOT,load,sha


def snapshot():
    native=packet()
    contract,data,inherited=build()
    hashes=dict(native["source_sha256"])
    hashes.update(inherited["source_sha256"])
    for p in [ROOT/"design.json",ROOT/"generate.py",ROOT/"collisions.py"]:
        hashes[str(p.relative_to(REPO))]=sha(p)
    return native,data,hashes


def main():
    d=load();native,data,hashes=snapshot()
    ends={r for p in d["paths"].values() for r in p["end_refs"]}
    for name,row in d["paths"].items():
        for q,ref in zip((row["points"][0],row["points"][-1]),row["end_refs"]):
            body=next(b for b in native["boxes"] if b[0]==ref)
            assert abs(body[1]+body[4]/2-q[0])<1e-6 and abs(body[2]+body[5]/2-q[1])<1e-6,(ref,q,body)
    boxes=[r for r in native["boxes"] if r[0] not in ends]
    for r in boxes:
        r[3]-=.2;r[6]+=.4
    cylinders=native["cylinders"]
    for r in cylinders:
        r[3]-=.2;r[5]+=.4
    other_boards=[r for r in data["boards"] if r[0]!="disconnect_carrier"]
    other_boxes=[r for r in data["envelopes"] if not r[0].startswith("disconnect_")]+data["port_envelopes"]
    source="""include <../../thermal-integration.scad>
positive_part="review";
"""
    for key,value in dict(positive_boxes=boxes,positive_cylinders=cylinders,positive_boards=native["boards"],positive_other_boards=other_boards,positive_other_boxes=other_boxes).items():source+=key+"="+json.dumps(value)+";\n"
    source+='''
module positive_copper(name){import(str(name,"-CU.stl"));}
module positive_cover(name){import(str(name,"-COVERED-ENVELOPE.stl"));}
module positive_hardware(){import("positive-links.stl");}
module positive_envelope(name,margin=0){minkowski(){positive_cover(name);cube([2*margin,2*margin,2*margin],center=true);}}
module positive_envelopes(margin=0){for(name=["ANA","DIG"])positive_envelope(name,margin);}
module positive_native_boards(){for(b=positive_boards)translate([b["datum"][0],b["datum"][1],b["datum"][2]-.2])difference(){linear_extrude(b["thickness_range_allocation_mm"][1]+.4)polygon(b["outline_relative_mm"]);for(h=b["mounting_holes_relative_mm"])translate([h[0],h[1],-.01])cylinder(d=h[2],h=3,$fn=64);}}
module positive_electronics(){positive_native_boards();for(b=positive_boxes)translate([b[1],b[2],b[3]])cube([b[4],b[5],b[6]]);for(c=positive_cylinders)translate([c[1],c[2],c[3]])cylinder(d=c[4],h=c[5],$fn=128);for(b=positive_other_boards)board_reserve(b);for(e=positive_other_boxes)translate([e[1],e[2],e[3]])cube([e[4],e[5],e[6]]);}
module positive_case(){retained_thermal_shell();thermal_metal_base();thermal_controls();lower_shell_fasteners();}
module positive_return_obstacles(){return_retention();return_fasteners();minkowski(){return_bars();cube([1.3,1.3,.2],center=true);}}
if(positive_part=="copper") {positive_copper("ANA");positive_copper("DIG");}
if(positive_part=="case_collision")intersection(){positive_envelopes(.35);positive_case();}
if(positive_part=="electronics_collision")intersection(){positive_envelopes(.35);positive_electronics();}
if(positive_part=="returns_collision")intersection(){positive_envelopes(.35);positive_return_obstacles();}
if(positive_part=="pair_collision")intersection(){positive_envelope("ANA",.225);positive_envelope("DIG",.225);}
if(positive_part=="positive_control")intersection(){positive_envelopes();translate([203.9,138.9,13.2])cube([.2,.2,.2]);}
if(positive_part=="review"){color([.8,.4,.12])positive_hardware();color([.1,.4,.3,.15])positive_electronics();color([.2,.3,.4,.1])positive_case();return_assembly();}
'''
    # OpenSCAD has no dictionary indexing. Native board records are lowered to
    # compact positional tuples before writing the final source.
    boards=[[b["datum"],b["thickness_range_allocation_mm"],b["outline_relative_mm"],b["mounting_holes_relative_mm"]] for b in native["boards"]]
    source=source.replace("positive_boards="+json.dumps(native["boards"]),"positive_boards="+json.dumps(boards))
    for key,value in [('b["datum"]','b[0]'),('b["thickness_range_allocation_mm"]','b[1]'),('b["outline_relative_mm"]','b[2]'),('b["mounting_holes_relative_mm"]','b[3]')]:source=source.replace(key,value)
    (OUT/"collisions.scad").write_text(source)
    report=dict(source_sha256=hashes,intentional_connected_studs_excluded=sorted(ends),native_component_records=native["component_records"],boxes=boxes,cylinders=cylinders,other_boxes=other_boxes,all_component_mate_heights_approved=False,physical_fit_verified=False)
    (OUT/"obstacles.json").write_text(json.dumps(report,indent=2)+"\n")


if __name__=="__main__":main()
