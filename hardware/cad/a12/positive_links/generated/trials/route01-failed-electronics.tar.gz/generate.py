"""Separate orthogonal machined positive-link candidate; no operating-port edits."""

import hashlib
import json
import math
from pathlib import Path

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[3]
OUT=ROOT/"generated"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load():
    return json.loads((ROOT/"design.json").read_text())


def direction(a,b):
    delta=[b[i]-a[i] for i in range(3)]
    axes=[i for i,v in enumerate(delta) if abs(v)>1e-7]
    assert len(axes)==1,(a,b,"Candidate paths use orthogonal segments")
    return axes[0]


def shape(d,name,maximum=False,wrap=0):
    import cadquery as cq
    p=d["paths"][name]["points"]
    w=d["bar"]["width_range"][1] if maximum else d["bar"]["width"]
    t=d["bar"]["thickness_range"][1] if maximum else d["bar"]["thickness"]
    land=d["bar"]["landing_range"][1] if maximum else d["bar"]["landing_diameter"]
    solids=[]
    for index,(a,b) in enumerate(zip(p,p[1:])):
        axis=direction(a,b)
        if axis==0:
            solids.append(cq.Solid.makeBox(abs(b[0]-a[0])+2*wrap,w+2*wrap,t+2*wrap,cq.Vector(min(a[0],b[0])-wrap,a[1]-w/2-wrap,a[2]-wrap)))
        elif axis==1:
            solids.append(cq.Solid.makeBox(w+2*wrap,abs(b[1]-a[1])+2*wrap,t+2*wrap,cq.Vector(a[0]-w/2-wrap,min(a[1],b[1])-wrap,a[2]-wrap)))
        else:
            neighbor=direction(p[index-1],a) if index else direction(b,p[index+2])
            assert neighbor in (0,1)
            dims=[t+2*wrap,w+2*wrap] if neighbor==0 else [w+2*wrap,t+2*wrap]
            solids.append(cq.Solid.makeBox(*dims,abs(b[2]-a[2])+t+2*wrap,cq.Vector(a[0]-dims[0]/2,a[1]-dims[1]/2,min(a[2],b[2])-wrap)))
    for index,q in enumerate(p):
        if index in (0,len(p)-1):
            disk=cq.Solid.makeCylinder(land/2+wrap,t+2*wrap,cq.Vector(q[0],q[1],q[2]-wrap))
            if name=="DIG" and index==0:
                flat=d["cap"]["dig_e28_copper_flat_plus_x"]+wrap
                disk=disk.cut(cq.Solid.makeBox(20,30,20,cq.Vector(q[0]+flat,q[1]-15,q[2]-5)))
            solids.append(disk)
        elif direction(p[index-1],q) in (0,1) and direction(q,p[index+1]) in (0,1):
            solids.append(cq.Solid.makeCylinder(w/2+wrap,t+2*wrap,cq.Vector(q[0],q[1],q[2]-wrap)))
    result=solids[0].fuse(*solids[1:]).clean()
    for q in (p[0],p[-1]):
        hole=d["bar"]["hole_range"][0] if maximum else d["bar"]["hole_diameter"]
        result=result.cut(cq.Solid.makeCylinder(hole/2,max(t+2*wrap+2,8),cq.Vector(q[0],q[1],q[2]-wrap-1)))
    assert result.isValid() and len(result.Solids())==1
    return result


def cap(d,name,end,outer_only=False):
    import cadquery as cq
    p=d["paths"][name]["points"][0 if end==0 else -1]
    h=d["terminal_hardware"]
    top=d["bar"]["thickness_range"][1]+h["washer_thickness"]+h["head_height_envelope"]+d["cap"]["roof_clearance"]+.5
    extra=d["cap"]["dimension_tolerance"] if outer_only else 0
    outer=cq.Solid.makeCylinder(d["cap"]["outer_diameter"]/2+extra,top+.5,cq.Vector(p[0],p[1],p[2]-.5))
    if name=="DIG" and end==0:
        outer=outer.cut(cq.Solid.makeBox(20,30,20,cq.Vector(p[0]+d["cap"]["dig_e28_outer_flat_plus_x"]+extra,p[1]-15,p[2]-2)))
    if outer_only:
        return outer
    cuts=[cq.Solid.makeCylinder(d["cap"]["inner_landing_diameter"]/2,2.0,cq.Vector(p[0],p[1],p[2]-.1)),cq.Solid.makeCylinder(d["cap"]["inner_head_diameter"]/2,top-.5,cq.Vector(p[0],p[1],p[2]-.6))]
    if name=="DIG" and end==0:
        cuts[0]=cuts[0].cut(cq.Solid.makeBox(20,30,20,cq.Vector(p[0]+d["cap"]["dig_e28_inner_flat_plus_x"],p[1]-15,p[2]-2)))
    # Allow the covered strip to leave the terminal cover. Retention remains a
    # separate positive-link part, not a cut or modification of frozen returns.
    q=d["paths"][name]["points"][1 if end==0 else -2]
    dx,dy=q[0]-p[0],q[1]-p[1]
    if abs(dx)>0:
        cuts.append(cq.Solid.makeBox(20,8,2.2,cq.Vector(p[0] if dx>0 else p[0]-20,p[1]-4,p[2]-.4)))
    else:
        cuts.append(cq.Solid.makeBox(8,20,2.2,cq.Vector(p[0]-4,p[1] if dy>0 else p[1]-20,p[2]-.4)))
    return outer.cut(*cuts).clean()


def main():
    import cadquery as cq
    d=load();OUT.mkdir(exist_ok=True)
    report={}
    assembly=[]
    for name in d["paths"]:
        cu=shape(d,name)
        covered=shape(d,name,maximum=True,wrap=d["insulation"]["maximum_build_each_face_allocation_mm"])
        # Remove the wrapped-region envelope at bare landing faces. Actual
        # terminal caps provide insulation around those intentional contacts.
        for q in (d["paths"][name]["points"][0],d["paths"][name]["points"][-1]):
            covered=covered.cut(cq.Solid.makeCylinder(6,8,cq.Vector(q[0],q[1],q[2]-2)))
        envelope=covered.fuse(*[cap(d,name,i,True) for i in (0,1)]).clean()
        for label,obj in [(name+"-CU",cu),(name+"-COVERED-ENVELOPE",envelope)]+[(name+"-CAP"+str(i),cap(d,name,i)) for i in (0,1)]:
            assert obj.isValid()
            cq.exporters.export(obj,str(OUT/(label+".step")))
            cq.exporters.export(obj,str(OUT/(label+".stl")),tolerance=.01,angularTolerance=.05)
            report[label]=dict(volume_mm3=obj.Volume(),solid_count=len(obj.Solids()),valid=obj.isValid())
        assembly.extend([cu]+[cap(d,name,i) for i in (0,1)])
    cq.exporters.export(cq.Compound.makeCompound(assembly),str(OUT/"positive-links.step"))
    cq.exporters.export(cq.Compound.makeCompound(assembly),str(OUT/"positive-links.stl"),tolerance=.01)
    minimum=(d["bar"]["width_range"][0]*d["bar"]["thickness_range"][0])-4*d["bar"]["maximum_edge_break"]**2
    neck=(d["bar"]["landing_range"][0]-d["bar"]["hole_range"][1])*d["bar"]["thickness_range"][0]-4*d["bar"]["maximum_edge_break"]**2
    report["analytical_bulk_minimum_mm2"]=minimum;report["analytical_neck_minimum_mm2"]=neck
    report["normal_corner_sections_independently_checked"]=False
    report["physical_qualified"]=False
    (OUT/"geometry.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))


if __name__=="__main__":main()
