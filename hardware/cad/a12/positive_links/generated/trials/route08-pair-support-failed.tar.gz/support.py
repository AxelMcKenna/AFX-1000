"""New bonded PEEK pedestal, independently removable saddle keepers."""


def parts(d, maximum=False, film_override=None):
    import cadquery as cq

    s = d["support"]
    cx, cy = s["foot_centre_xy"]
    film = (
        d["insulation"]["maximum_build_each_face_allocation_mm"]
        if maximum
        else s["planned_received_wrap_face_mm"]
    )
    if film_override is not None:
        film = film_override
    t = d["bar"]["thickness_range"][1] if maximum else d["bar"]["thickness"]
    base = s["floor_z"] + s["bond_nominal_thickness"]
    feet = cq.Solid.makeBox(
        *s["foot_xy"],
        s["foot_thickness"],
        cq.Vector(cx - s["foot_xy"][0] / 2, cy - s["foot_xy"][1] / 2, base),
    )
    level = 20.5 - film
    lower = level - s["arm_vertical_thickness"]
    mast = cq.Solid.makeCylinder(
        s["mast_diameter"] / 2,
        level - base - s["foot_thickness"],
        cq.Vector(cx, cy, base + s["foot_thickness"]),
    )
    arm = cq.Solid.makeBox(
        s["arm_x"] - cx,
        s["arm_width"],
        s["arm_vertical_thickness"],
        cq.Vector(cx, cy - s["arm_width"] / 2, lower),
    )
    y0 = min(q[1] for q in s["saddles"].values())
    y1 = max(q[1] for q in s["saddles"].values())
    long = cq.Solid.makeBox(
        s["arm_width"],
        y1 - y0,
        s["arm_vertical_thickness"],
        cq.Vector(s["arm_x"] - s["arm_width"] / 2, y0, lower),
    )
    main = feet.fuse(mast, arm, long).clean()
    out = {}
    thread_cuts = []
    for name, q in s["saddles"].items():
        floor = cq.Solid.makeBox(
            s["saddle_x_length"],
            s["saddle_y_length"],
            s["arm_vertical_thickness"],
            cq.Vector(q[0] - s["saddle_x_length"] / 2, q[1] - s["saddle_y_length"] / 2, lower),
        )
        top = q[2] + t + film + s["keeper_gap_allocation"]
        bearing = level + s["matched_screw_bearing_above_saddle_floor_mm"]
        keeper = cq.Solid.makeBox(
            s["saddle_x_length"],
            s["saddle_y_length"],
            bearing - top,
            cq.Vector(q[0] - s["saddle_x_length"] / 2, q[1] - s["saddle_y_length"] / 2, top),
        )
        for index, dy in enumerate(s["screw_y_offsets"]):
            x, y = q[0], q[1] + dy
            floor = floor.cut(cq.Solid.makeCylinder(0.65, 3.2, cq.Vector(x, y, lower - 0.1)))
            thread_cuts.append(cq.Solid.makeCylinder(0.65, 3.2, cq.Vector(x, y, lower - 0.1)))
            keeper = keeper.cut(cq.Solid.makeCylinder(0.9, bearing - top + 0.2, cq.Vector(x, y, top - 0.1)))
            # ThroughM1.6 thread is a drawing callout; no helical BREP claim.
            length = s["screw_length_receiving_range_project_mm"][1] if maximum else s["screw_length_nominal"]
            screw = cq.Solid.makeCylinder(0.825, length, cq.Vector(x, y, bearing - length)).fuse(
                cq.Solid.makeCylinder(1.5, 1.6, cq.Vector(x, y, bearing))
            )
            out[name + "-SADDLE-SCREW" + str(index)] = screw
        main = main.fuse(floor).clean()
        out[name + "-SADDLE-KEEPER"] = keeper
    out["BONDED-PEDESTAL"] = main.cut(*thread_cuts).clean()
    assert all(obj.isValid() and len(obj.Solids()) == 1 for obj in out.values())
    return out
