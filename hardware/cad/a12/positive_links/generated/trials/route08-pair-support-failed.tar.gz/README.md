# A12-PB01 positive busbar prototype — unreleased

This separate candidate replaces the obstructed pair of wire links with integral machined C110 copper shapes. The electrical ports, operating nets, thermal kit and ground-return kit are unchanged. It is a prototype to quote and test, not the selected production connection. See `generated/verification.json` for the exact native collision result and source freshness; a drawing or a clear earlier trial is not an acceptance record.

`generated/positive-links.step` contains both copper links, four two-piece PEEK terminal caps with captive M1.6 cross-fasteners, the four M3 terminal screw/washer assemblies, and a separate bonded PEEK support with removable saddle keepers. Individual STEP/STL parts, a dimensioned plan with XYZ stations, and a CPU projection are alongside it. The tape is an assembly operation; separate maximum covered envelopes represent its allocated build, cap motion and fastening geometry. STEP solids are not approved fabrication drawings.

The finished-metal strip is6.4±0.1mm wide and1.2±0.2mm thick, with10±0.05mm terminal lands and3.4±0.05mm holes. The E28 digital land has a rear flat at localX+4mm to clear the ground terminal. The critical forward hole neck retains the full diameter. Copper-only area calculations subtract up to10µm of tin on every face and the project edge-break allocation. Local independent BREP slabs inspect every straight midpoint, corner bisector and terminal hole. These witnesses are not a proof of the global minimum or a3D current-crowding analysis. The entire assembled link must still measure≤2mΩ including its actual studs, solder, copper and contacts.

The E28 and P03 nominal terminal faces remainZ11.6 and13.1. Their5mm stud height has general manufacturer tolerances and an unqualified seating process. Receive and measure the actual assembled planes, then produce matched blanks; never pull a stiff link into position by tightening its terminals. Both P03 board-height6.3..6.7 and its1.44..1.76mm PCB allocation affect the measured planes. Intermediate high spans are chassis-referenced. A new measured-plane configuration requires regenerated geometry and renewed source-bound checks; the supplied default is not a manual bend instruction.

The ANA link escapes around the time pot, crosses the bulk-capacitor gap below the full4.5mm switch-tail allocation, and descends before the pitch pot. The digital link detours below the Trill board and over the ground bar, then rises in front of the tall E19 headers. A same-axis exit is required at each vertical riser: an earlier perpendicular exit reduced an actual section to3.55mm² and was rejected. Earlier inadequate switch coverage, lid-boss, terminal-cap travel/wall and self-interference trials remain explicitly superseded/rejected under `generated/trials/`.

Selected candidate insulation is3M92 polyimide tape, two complete wraps with staggered seams, with a0.32mm maximum per-face receiving allocation. The supplier's nominal thickness and dielectric test do not guarantee the wrapped assembly. The PEEK cap cavity is matched to received copper thickness; a fixed generous cavity would allow more cap travel than the collision envelope. Its M1.6 nut pocket has a separate internal wall above the M3 head cavity. The P03 digital cap's upper bridge is offset4mm rearward to avoid the scene5 switch tails. Use the supplied split-cap pieces, not the superseded simple cover shapes.

The new support's10×12×0.4mm foot bonds to the retained plastic floor at(166,123.5), with a3mm mast between PCB edges. Its two2.5×13mm saddles are at(171,133.125) and(171,100.5). Keeper height is matched to received copper and wrap; the M1.6×6 screw bearing plane stays3.5mm above the actual saddle floor, providing nominal2.5mm engagement. The5.8..6.2mm length range is a receiving requirement pending supplier tolerance approval. No strength credit is taken for this2mm-wide cantilever, its PEEK threads, adhesive or printed floor. DP460EG is a real selected adhesive candidate; its indicative datasheet properties do not qualify PEEK-to-printed-polymer adhesion. A failed bond, a loose screw or thermal expansion must not expose a live face: fault retention and life remain bench requirements.

Native checks use actual both-face P03/E28 records, all14 mount-head/washer requirements, refreshed source-bound E07/E18/E19/E20 packets, the controlled rotated B3F body/tail bank, controls and holder/key motion, the frozen ground bars/retainers/fasteners, case and metal base. Unknown mated harness heights and complete loose wiring remain explicitly unapproved. The collision allowance is0.10mm position plus0.25mm clearance; it is not a demonstrated manufacturing tolerance. The bonded support's floor seating is intentional; its case check clips belowZ4 while the separate electronics check includes the foot. No geometry belowZ4 besides the declared foot/bond seat is intended to penetrate the case.

Run from the repository root with a CadQuery environment:

```
python -m hardware.cad.a12.positive_links.generate
python -m hardware.cad.a12.positive_links.analysis
python -m hardware.cad.a12.positive_links.self_check
python -m hardware.cad.a12.positive_links.collisions
python -m hardware.cad.a12.positive_links.verify --openscad /path/to/OpenSCAD
python -m hardware.cad.a12.positive_links.drawings
python3 -m unittest tests.tooling.test_positive_links
```

The source snapshot refuses missing height classes and stale inherited placement packets. Native verification refuses stale geometry or obstacle inputs before starting, records native logs/input/output hashes, and rejects a source changed during the run. Portable tests require neither vendor downloads nor CAD tools. Optional BREP regeneration is separate. See `bench-requirements.json` for the actual remaining measurement and process holds; every release and physical qualification flag remains false.
