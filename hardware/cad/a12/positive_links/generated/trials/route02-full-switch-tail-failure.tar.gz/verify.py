"""Source-bound native collision screens; failures remain reviewable evidence."""

import argparse
import json
import subprocess

from hardware.cad.a12.thermal.verify import binary_stl

from .generate import OUT,REPO,load,sha


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--openscad",required=True);args=parser.parse_args()
    packet=json.loads((OUT/"obstacles.json").read_text());checks={}
    for name in ["copper","case_collision","electronics_collision","returns_collision","pair_collision","positive_control"]:
        target=OUT/("native-"+name+".stl");target.unlink(missing_ok=True)
        cmd=[args.openscad,"--hardwarnings","--backend","Manifold","--export-format","binstl"]
        for value in ['part="positive_only"','thermal_part="positive_only"',f'positive_part="{name}"']:cmd += ["-D",value]
        cmd += ["-o",str(target),str(OUT/"collisions.scad")]
        run=subprocess.run(cmd,capture_output=True,text=True,timeout=180)
        log=run.stdout+run.stderr;(OUT/("native-"+name+".log")).write_text(log)
        if run.returncode==1 and "Current top level object is empty." in log:
            checks[name]=dict(result="empty",volume_mm3=0)
        elif run.returncode==0 and "NoError" in log and "WARNING" not in log and "ERROR" not in log:
            checks[name]=dict(result="valid native manifold",**binary_stl(target))
        else:
            checks[name]=dict(result="native failure",returncode=run.returncode,log=log)
    failures=[name for name,row in checks.items() if name.endswith("collision") and row.get("volume_mm3",1)>1e-6]
    positive=checks["positive_control"].get("volume_mm3",0)>.007
    stale=[path for path,expected in packet["source_sha256"].items() if sha(REPO/path)!=expected]
    report=dict(native_checks=checks,collision_failures=failures,positive_control_detected=positive,stale_sources=stale,source_sha256=packet["source_sha256"],all_component_mate_heights_approved=False,cover_and_restraint_qualified=False,electrical_joint_qualified=False,physical_fit_verified=False,fabrication_released=False,selected_for_production=False)
    (OUT/"verification.json").write_text(json.dumps(report,indent=2)+"\n");print(json.dumps(report,indent=2))


if __name__=="__main__":main()
