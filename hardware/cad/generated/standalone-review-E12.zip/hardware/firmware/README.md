# Standalone embedded prototype

This application builds the existing RMX engine for Daisy Seed3. Audio processing,
factory samples, tempo detection, front controls and feedback run on the module;
no Mac, USB host or network connection is required for operation. It has been
cross-compiled, **not run on a physical board**. Analog circuitry, power, bypass
hardware, assembled controls and on-device validation remain required.

The default build uses the onboard codec for bring-up. The
[E04 noise screen](../electronics/README.md#e04-converter-gain-and-noise-screen)
does not approve that converter for the final reference-performance design.
The [F02 external-converter profile](EXTERNAL-CONVERTER.md) now implements a
separate ES9292QPRO/SAI2 adapter with configuration/readback, silent startup and
hardware-qualification gating. Both profiles cross-compile; neither has run on
hardware. Preserve the wiring contract below for the default onboard build.
Use the matching F02/E11 pin plan for `PROFILE=external`. F02 additionally waits
for independent input settling, masks unsettled ADC data before DSP histories
and keeps input qualification warm during ordinary manual bypass. Both ARM
profiles and all eight host suites pass; physical timing/audio remain unverified.

## What is implemented

- Fixed stereo 48 kHz / 128-frame audio callback, with preallocated factory bank.
- 48 MiB SDRAM arena for large vectors; bounded metadata in internal SRAM.
- Ten ADC pots, two MCP23017 input expanders, Trill Craft touch acquisition,
  AS5600 release sensing, and a four-chip TLC5947 LED/display chain.
- Front control behavior shared with host-tested `HardwareControls.h`.
- Two-endpoint lever calibration with two alternating CRC-checked QSPI records.
- Audio-callback heartbeat and relay permit. Permit requires fresh controls,
  valid calibration, healthy startup and no latched processing fault.
- Dry-bypass request if I/O fails or the foreground loop stalls. Processing
  resumes only after healthy inputs remain stable for 350 ms. Callback overruns
  above 2400 us or nonfinite samples latch a fault until restart.
- Rear CONNECTION selects analog gain through a sequenced driver: immediate dry
  bypass, 8 ms debounce, 20 ms dry wait, gain change, 30 ms settling, then the
  existing healthy rearm interval. It does not enable wet-only DSP routing.
- E02 latch feedback on D28: allow 20 ms for initial arming, remove permit on
  lost feedback, and latch a fault if loss persists for 20 ms. The manual-switch
  poles may arrive at different times within that allowance.
- A fresh 350 ms continuous eligibility interval follows manual bypass,
  calibration, gain settling, input faults and the initial 128-block audio
  warm-up. It prevents a premature latch clock on manual bypass release.

These are software behaviors, not proof that the proposed circuits satisfy them.
The external watchdog, relay gating and normally closed bypass must be built and
measured independently. The DAC float output is clamped to [-1,1]; that does not
establish analog headroom or a matching gain range.

## Build

Use the exact SDK revision in `dependencies.json`, including its recursive
submodules. Keep it outside the firmware source directory:

```sh
git clone https://github.com/daisyaudio/libDaisy.git build-hardware/libDaisy
git -C build-hardware/libDaisy checkout f715e4875b2d28445d0c11a0a17f064a248f69d0
git -C build-hardware/libDaisy submodule update --init --recursive
make -C build-hardware/libDaisy -j4 GCC_PATH=/path/to/arm-toolchain/bin
make -C hardware/firmware PROFILE=onboard -j4 GCC_PATH=/path/to/arm-toolchain/bin
make -C hardware/firmware PROFILE=external -j4 GCC_PATH=/path/to/arm-toolchain/bin
```

`LIBDAISY_DIR` can override the default `../../build-hardware/libDaisy` when invoking
make from `hardware/firmware`. Arm GNU Toolchain 15.3.Rel2 was checked. C++20 is
required. The application uses `BOOT_SRAM`, not the 128 KiB internal-flash layout.
Install the matching Daisy bootloader on the actual Seed3 before programming the
application through its DFU workflow. No hardware was programmed in this work.

Build products are `build/rmx_standalone.bin`, `.elf`, `.hex` and `.map`. The
application reserves QSPI offsets `0x007f0000` and `0x007f1000` for calibration.
Keep firmware, assets and any future storage partition clear of those sectors.
The records do not depend on native filesystem/syscall support.

The pinned SDK/newlib link emits warnings for unsupported host POSIX syscalls
and the SDK SRAM linker segment's RWX permissions. No POSIX file or terminal I/O
is used by this application. microSD must use the embedded FatFs adapter; it is
not implemented yet. The linker map and actual hardware remain the authority for
memory use and timing.

## Wiring contract

All logic and I2C pull-ups are 3.3 V. Keep analog pot excitation/returns on the
module's analog supply/ground domain, with the manufacturer's required AGND/DGND
connection. Do not power the processor from the logic output pins.

| Seed logical pin | Function |
| --- | --- |
| D0 | Hardware bypass sense, active low; switch also directly gates relay enable |
| D1-D6 | Reserved for SDMMC storage; not initialized by this revision |
| D7 | TLC5947 XLAT |
| D8 | SPI1 clock for TLC5947 |
| D9 | Gain relay driver request; low Master / high Send-Return; external pull-down |
| D10 | SPI1 MOSI to TLC5947 IC0 SIN; chain SOUT to the next IC |
| D11 / D12 | I2C1 SCL / SDA at 400 kHz |
| D13 | Audio-callback heartbeat to independent watchdog |
| D14 | TLC5947 BLANK; external pull-up keeps lamps off during reset |
| D15-D24 | Input, Output, Low, Mid, Hi, Scene Depth, X Level, Pitch, Sub1, Sub2 pots |
| D25 | Master/send-return mode sense, active low for send-return |
| D26 | Processing relay permit; external pull-down and watchdog/bypass gating required |
| D27 | Shared MCP23017 RESET, active low; external pull-up required |
| D28 | E02 latch-Q feedback, active high; MCU pull-down makes a missing connection low |
| D29 / D30 | Reserved; do not connect the panel USB cable here in this prototype |

The [E09 external-converter interface plan](../electronics/converter/interface-plan.json)
is the basis of the separate external profile: D25–D28 become dual-slave SAI2, D29 permit,
D30 latch feedback and D0 codec-run/shared MCP reset. A third MCP23017 reads
rear controls, ANALOG_OK and E11 INPUT_READY. F02 implements that adapter as
`PROFILE=external`; the table above describes `PROFILE=onboard`. F02 waits for
hardware ANALOG_OK, continuous streaming/clock/ramp-up qualification and the
independent input sequence before a permit edge. GPA2 ANALOG_OK needs47kΩ and
GPA3 INPUT_READY needs270kΩ receiving pull-downs on the unfinished control PCB;
both internal pull-ups are disabled. E11 replaces E02/E03 for this profile.

The service connector uses a short USB extension to the module's own USB-C port.
Supply voltage and polarity are not finalized until the analog/power schematic
is reviewed. Power switching, line gain switching and relay-coil drive are not
implemented by connecting a GPIO directly to a coil or analog audio signal.

The [E02 watchdog/driver schematic](../electronics/bypass/README.md) drives two DPDT gain relays
controlled by D9 through a MOSFET driver, independently of the two bypass relays.
`ConnectionMode.h` guards gain transitions while dry bypass is requested. Normal
standalone routing retains the dry signal; wet-only needs a separate future
setting for parallel auxiliary buses. Actual coil timing and contact bounce must
be measured before accepting the prototype intervals.

The bypass watchdog requires a hardware fault latch: WDO can recover after its
reset interval even with D26 frozen high. The proposed edge-armed latch stays
disarmed until a new D26 rising edge. This circuit remains a design draft; the
firmware's GPIO behavior cannot supply that independent protection by itself.

E02 manual bypass uses a closed PROCESS_OK contact loop as well as the separate
active-low D0 sense pole; an open process-loop cable inhibits hardware enable.
Its J2.5 routes latch Q to D28. Missing feedback prevents a successful arm attempt
and results in a latched fault. D28 senses the logic latch, not relay contacts.
Full analog-rail supervision and actual circuit testing remain mandatory gates.

| I2C device | 7-bit address | Use |
| --- | --- | --- |
| MCP23017 #0 | 0x20 | Inputs 0-15 |
| MCP23017 #1 | 0x21 | Inputs 16-31; A0 high, A1/A2 low |
| Trill Craft | 0x30 | Electrodes 0-7; other channels remain unused |
| AS5600 | 0x36 | Status and raw angle |

Each expander input is active low. Within a chip, GPIOA bits 0-7 precede GPIOB
bits 0-7. Inputs 0-28 follow `buttonIds` in `HardwareControls.h`; input 29 is
Default/User, input 30 Back Spin, input 31 Vinyl Brake. Neither release end input
means Echo; both asserted is a wiring/state error. Configure the mode switch so
it cannot short both end contacts simultaneously.

Trill uses DIFF mode, ultra-fast 10-bit scans, prescaler 2, and a baseline update
at startup. Eight electrodes feed a centroid around the strongest touch. The
threshold is a prototype constant in `WireFormat.h`, not a calibrated production
setting. Finger-off startup, cover thickness, noise rejection and latency must
be tested. Protocol reference: [Bela's Trill-Arduino source](https://github.com/BelaPlatform/Trill-Arduino),
with scan behavior described in the [manufacturer's settings guide](https://learn.bela.io/using-trill/settings-and-sensitivity/).

## LED/display channel contract

Global channel `n` maps to IC `n/24`, output `n%24`. IC0 is nearest the MCU.
`WireFormat.h` sends the furthest/highest channel first, MSB first.

| Channels | Indication |
| --- | --- |
| 0-9 | Scene selections in engine order |
| 10-13 | Isolator mode |
| 14-15 | Input / sampler source |
| 16-19 | Pad trigger flashes |
| 20-24 | Quantize, Auto, Roll, Overdub, Hold |
| 25-44 / 45-64 | Input / output meters |
| 65-68 | Sample bank |
| 69-92 | Three digits, eight channels each, a/b/c/d/e/f/g/decimal point |
| 93-95 | Ring R/G/B |

Current limits are hardware-set; PWM brightness is not a current limiter. Use
common-anode display parts and the TLC5947 manufacturer's required current-set,
decoupling and thermal design. Default/User currently changes the shared flag;
loading user settings/presets from storage remains open.

## Prototype calibration and first-power procedure

First establish power, grounded analog I/O and normally closed dry bypass with
the processor disabled. Confirm the relay cannot engage when the watchdog is
missing/stopped. Measure the actual analog levels before connecting a mixer.

An uncalibrated unit stays in dry bypass and shows `CAL`. With the rear hardware
bypass selected and the lever released, hold **Bank + Tap for two seconds** to
capture home. Release those buttons; the display shows `End`. Pull to the
mechanical end stop and hold Bank + Tap for two seconds again. Audio pauses while
the new CRC record is written/read back. Both rotation directions and encoder
wrap are supported. Invalid travel is rejected and the unit remains bypassed.

This requires the assembled lever and sensor. Physical stops, magnet field,
spring return, bearings and actual travel must be checked before accepting that
calibration. Do not calibrate against an unsupported or forced lever position.

## Remaining bring-up gates

- Measure worst-case callback time on Seed3 with all effects, pad voices, rolls,
  input scanning and LED traffic active; host timing is not this evidence.
- Validate both channels, unity gain, clipping, send/return routing, converter
  noise/distortion and physical round-trip latency.
- Build the external watchdog/bypass and verify boot, MCU halt, I/O fault,
  brownout, power loss and reset behavior with an audio signal.
- Complete microSD sample/preset loading with the 32-second aggregate sample cap,
  startup asset installation and an explicit full-bank replacement policy.
- Add calibration/preset recovery tests, measured ADC endpoints and physical
  control/LED tests. No claim of a two-hour hardware soak is made.
