# E15 DC input protection and startup guard

E15 adds a 35-component candidate input schematic for the standalone unit. It
uses an external 12 V, 3 A adapter, a center-positive PJ-102AH inlet, a backup
fuse/TVS, external reverse-blocking MOSFET and TPS26630 eFuse. An independent
auxiliary supply powers the rear shutdown switch and converter-enable pull-up.
This is a design prototype, not a fabrication or assembly release.

The native schematic passes all-severity ERC, independent exported pin/value
and critical footprint contracts, 80 threshold corners and a fresh E14 supply
interface check. Calculations include engineering allocations; they are not
semiconductor transient simulation or physical protection evidence.

## Power path and wiring

```text
12V inlet -> 4A backup fuse -> VIN_SYS -> reverse-blocking Q1 -> VIN_IC
                                                                |
                                      +-------------------------+
                                      |                         |
                                  TPS7A1601                 TPS26630
                                  ~2.5V AUX                 internal pass FET
                                      |                         |
                          power switch / PG pull-up        VIN_PROTECTED -> E14 J1
                                      |                         |
                                   SHDN                PGOOD / POWER_READY -> E14 J5
                                                                |
                                                    guarded digital/PRE buck enables
```

| Interface | Pins in order | Connection |
| --- | --- | --- |
| J1 | center+, sleeve, unused switched sleeve | External adapter; center positive |
| J2 | VIN_PROTECTED, AGND | E14 J1, full input current |
| J3 | AGND, POWER_READY | E14 J5, required startup guard |
| J4 | SWITCH_SUPPLY, POWER_RUN, AGND | Panel switch: ON1, common2, OFF3 |
| J5 | V2V5_AUX, AGND | Auxiliary test/future protection boundary |

The exact adapter remains unselected. Its required delivered voltage at the
inlet is 11.4–12.6 V, including cable drop. Engineering headers do not establish
production connector current ratings or keying. AUX must never be tied to the
Seed3 3.3 V output. S1 is the panel switch component; J4 describes its harness
boundary, not a second switch.

Q1 source pins1–3 face VIN_SYS; its drain pad5 faces VIN_IC. Its body diode
allows cold positive startup. The eFuse's internal body diode points from OUT
back to IN, opposing Q1 for reverse blocking. Q2 source also follows VIN_SYS;
connecting it to ground would defeat the manufacturer's reverse-input topology.
The auxiliary LDO starts through Q1's body diode before the internal pass FET
turns on, avoiding a startup dependency on the main digital supply.

PGOOD requires both the PGTH threshold and the internal pass FET to be enhanced.
E14 now has 156 components, including J5. Its two bucks share SUPPLY_ENABLE,
fed through parallel 10k top/22k bottom receiving dividers. A missing J3/J5
cable holds them below disable threshold under the stated EN-current allocation.
The converters' internal EN currents have typical-only datasheet entries; the
screen allocates 10uA per pin and requires measurement over temperature.

The switch carries shutdown current. Its receiving 10k pulldown makes a missing
switch read OFF. Cycling it clears latched overcurrent/thermal faults. MODE is
open for latch-off; UV/OV faults have their own hysteretic recovery. The selected
TPS26630 lacks the optional2x overload-pulse feature. Switch contact reliability,
actuator orientation, panel fit and mechanical startup behavior remain open.

## Conditional electrical results

| Quantity | Calculated range / allocation |
| --- | --- |
| UVLO rising | 10.115–10.736 V at VIN_SYS |
| OV rising | 14.005–14.885 V at VIN_SYS |
| OV falling | 12.976–13.989 V |
| PGTH rising | 9.722–10.249 V at VIN_PROTECTED |
| AUX | Allocated 2.4–2.6 V, including reference/ratio/bias bounds |
| Main buck EN high / low | 1.464–1.772 V / at most0.277 V |
| Main buck EN, guard cable absent | At most0.223 V under current allocation |
| Switch ON / missing switch | At least2.177 V / at most0.101 V |
| Current limit | Nominal2.773 A; allocated2.489–3.061 A |
| Steady input plus ramp current | About2.354 A, including8mA protection overhead allowance |
| Minimum protected voltage at steady load | About11.039 V under resistance allocations |

The current-limit error allocation is10%, not a manufacturer guarantee at the
unlisted6.49k setting. The input path uses the eFuse's53mOhm full-temperature
maximum, jack30mOhm maximum, and hot blocking-FET40mOhm/fuse30mOhm/wiring20mOhm
allocations. Q1's datasheet resistance conditions use10V gate drive; the eFuse
driver can supply only8.3V at its minimum. Qualify the hot40mOhm allocation.
Q2 gate discharge at the minimum3V drive also needs qualification.

The220uF bulk capacitor is EEUFR1V221: body8x11.5mm, pitch3.5mm. Its950mArms
and56mOhm impedance specifications are at100kHz; actual switching waveform,
temperature, lifetime and PCB fit remain unchecked. The direct E14 capacitors
have a35uF minimum effective allocation. Including bulk tolerance and E15 C4
gives211.1uF minimum bus capacitance. The nominal-tolerance maximum is392.88uF;
the startup calculation allocates400uF and uses the nominal ramp-gain equation
with dVdT-current extremes and80–120nF timing capacitance. It does not prove
load-step response, full-temperature ramp timing or MOSFET safe operating area.

## Fault limits still requiring resolution

The bidirectional33V TVS avoids continuous avalanche on a24V adapter misplug.
Its rated-pulse clamp is53.3V; actual wiring overshoot, pulse energy and surge
class are unverified. The4A0451004.MRL is backup protection. Its nominal cold
resistance and melting I2t do not prove clearing with a current-limited adapter.
Fuse/adapter/TVS coordination and temperature derating remain open.

A BAS116 clamp and auxiliary bleeder bound positive OVP-pin voltage under a
1.3V forward-drop allocation. The bleeder exceeds calculated injection through
309k at60V. Negative/reverse-input and partial-power pin behavior, clamp
temperature limits and output undershoot still require bench validation.

**The static OV trip does not prove that E14 remains below its16V input limit
during a fast fault.** The report computes a transferred-charge budget and
includes hypothetical current/delay cases that exceed it. A3A adapter rating
cannot be treated as an instantaneous current bound. The datasheet's8.5–14us
OVP-to-FLT timing is measured after20mV comparator overdrive; it does not bound
all wiring, gate and load-current interruption behavior. Measure transferred
charge and revise capacitance, thresholds or protection architecture if needed.

Final analog/digital rail OV disconnects, complete PCB layout, thermal design,
enclosure placement, actual startup/shutdown and reverse/charged-output tests
remain unfinished. E13's rail-fault eligibility signal does not disconnect power.

## Regeneration

```sh
python3 hardware/electronics/input_protection/generate.py
python3 hardware/electronics/power_supply/verify.py --kicad-cli /path/to/kicad-cli
python3 hardware/electronics/input_protection/verify.py --kicad-cli /path/to/kicad-cli
```

The E14 verifier must run first. E15 checks its captured source hashes and freshly
exports the current supply schematic. See `dependencies.json`, `integration.json`
and `generated/verification.json` for sources, boundaries and evidence.
