# Standalone RMX hardware

The physical unit is a standalone stereo audio effects processor. It must process
audio, run its sampler, read all performance controls, and drive its indicators
without a Mac, DAW, USB host, or network connection. USB is for service, firmware
updates and optional MIDI; it is not the audio processing architecture.

## Working architecture

Use an embedded audio MCU/module with local RAM, stereo converters and microSD
storage. The current working candidate is **Daisy Seed3, 64 MB external SDRAM**,
running the existing portable C++ engine at **48 kHz / 128 frames**. This is a
prototype selection with hardware assembly and worst-case timing measurements
still pending. The module's higher supported sample rates do not establish that
this engine fits or meets its deadline at those rates.

The [manufacturer's Seed3 documentation](https://docs.daisy.audio/hardware/Seed3/)
provides the board specification and downloadable mechanical drawings. The
module is 51 × 18 mm, uses an STM32H750 at 480 MHz, and includes a TAC5242 stereo
codec. This is enough information to reserve board space, not proof of final
audio performance or compatibility with DJ mixer signal levels.

The [E04 audio screen](electronics/README.md#e04-converter-gain-and-noise-screen)
does not approve the onboard codec for the reference-performance design: under
the project's 20 dB headroom/nominal-level noise assumptions, even its optimistic
differential figures leave no budget for the minimum S/N targets. Seed3 remains
the firmware/control bring-up platform. ES9292QPRO external conversion is the
next candidate; its circuit, procurement, clocking and revised MCU pin adapter
still need implementation and verification. This does not change standalone
operation or lower the audio targets.

```text
Stereo line input ──┬── input protection / gain ── ADC ── DSP ── DAC ── output stage ──┐
                   │                                                               ├── Stereo line output
                   └──────────────── normally closed relay bypass ─────────────────┘

Controls / touch strip ── ADC + GPIO expanders ── embedded control dispatcher ── DSP
DSP / control state ── LED drivers + BPM display
microSD ── presets / samples / calibration
External low-voltage DC ── protected power input ── digital / analog supplies
Independent watchdog + power-good ── relay enable (fails to dry bypass)
```

The normally closed relay path must pass dry audio when power is absent. Relays
must select one output source at a time; processed and dry outputs must never be
hard-wired together. A watchdog circuit must remove relay enable when valid audio
callbacks stop, including if the UI task remains alive. Software bypass and
power-failure bypass are separate behaviors.

The [E01 electronics design basis](electronics/README.md) calculates both line
gain ranges and power/headroom constraints. Its draft uses separate input
isolation and output selector relays, two gain relays, and an edge-armed watchdog
latch. These are circuit contracts pending a complete schematic, not assembled
electronics. The rear CONNECTION switch selects gain independently of wet/dry
routing.

The [E02 native watchdog/driver schematic](electronics/bypass/README.md) now
includes local 3.3 V/5 V supervision, Schmitt qualification, manual process-loop
continuity, an edge-armed latch and two coil drivers. Firmware monitors latch Q
on D28. Native ERC and 25 ideal fault cases pass; six host suites pass and the
embedded application cross-compiles. Analog-rail monitoring, PCB layout and
physical bypass/audio performance remain unfinished.

The [E03 stereo contact schematic](electronics/audio_bypass/README.md) now
connects the two bypass relays to that driver. It passes native ERC, checks all
four settled relay combinations and matches the E02 coil interface. The relay
land pattern also matches the manufacturer's nominal drawing. The contacts,
analog stages and power circuits still need an integrated PCB and bench tests.

The [E05 native output stage](electronics/output_stage/README.md) adds separate
master/send-return drivers, coupling/discharge networks and the output gain
relay. Native ERC, 12 ideal AC cases, four ideal DC cases and 256 component
tolerance cases pass. The converter/receiver, input range and supplies remain
unfinished. All four proposed analog rails need independent supervision.

The [A03/E06 placement](electronics/output_stage/generated/placement-verification.json)
now puts all 41 output footprints into the revised enclosure with staggered
capacitors, a lower board and a floor recess. Modeled component/lead clearances
and the seven enclosure solids pass. Native PCB placement/library/parity checks
pass, with 78 connections still open. Physical fit, routing and the remaining
converter/input/power placement are not complete.

## Memory evidence

`rmx_hardware_profile` measures C++ heap payload for the actual engine and factory
sample bank on the development host. It also exercises the processing path and
reports any allocations during that interval. It does not measure MCU allocator
overhead, firmware code, stacks, DMA buffers, or processor timing.

```sh
cmake -S . -B build-hardware -DCMAKE_BUILD_TYPE=Release
cmake --build build-hardware --target rmx_hardware_profile --parallel 4
./build-hardware/rmx_hardware_profile 48000
./build-hardware/rmx_hardware_profile 96000
```

At 48 kHz the current engine allocates 26,433,392 bytes of buffers; the factory
bank adds 2,396,160 bytes. A proposed 32-second **aggregate** stereo sample limit
would bring engine + sample payload to 38,721,392 bytes, below a 48 MiB heap
reservation. This is an initial capacity constraint, not an implemented sample
loader limit. Bank replacement must not transiently retain a second full bank.

At 96 kHz, engine + that sample limit would require 77,442,112 bytes, so it is
rejected for this 64 MB module. Preserve the desktop's existing rates; the
standalone adapter will explicitly support 48 kHz until a different memory
configuration and on-device profiling justify more.

## Mechanical work

See [CAD and control layout](cad/README.md). Preserve the RMX-style control
arrangement while adding the internal audio/power carrier, panel control boards,
release mechanism, optical parts, and rear I/O. Reserve the independent bypass
path and service access as part of the layout.

The [component shortlist](components.md) records the current controls, sensor,
display and driver choices. The [embedded prototype](firmware/README.md) now
builds for Seed3 with local audio processing, control input and feedback. It has
not been flashed or tested on a physical board.

## Required completion gates

- [x] Standalone operation is the selected architecture.
- [x] First housing and control layout exists.
- [x] Actual C++ buffer allocations measured; initial 48 kHz memory budget fits.
- [ ] Component selection and manufacturer dimension checks completed.
- [x] A02 CAD contains component reserves, PCB supports, rear I/O and lever motion.
- [x] Seven CAD solids rendered, mesh checked, and fit coupon exported.
- [x] Embedded engine adapter cross-compiles with the pinned board support package.
- [x] Front control logic, feedback serialization and SDRAM arena have host checks.
- [ ] Control/sensor/LED drivers and calibration bench tested on the actual board.
- [ ] Audio gain stages, bypass, watchdog and power schematics reviewed.
- [ ] Carrier and control PCBs routed and checked.
- [ ] Physical control coupon assembled and hand spacing reviewed.
- [ ] Full prototype assembled and runs with no computer connected.
- [ ] Worst-case MCU timing, round-trip latency, power-failure bypass, noise,
      distortion, headroom, thermal and two-hour soak tests measured.

The remaining physical gates require the actual parts and test equipment. CAD
clearance checks and host tests cannot substitute for those measurements.

The [B01 button fit kit](cad/BUTTON-FIT.md) now includes two key sizes, three
guide-clearance options, a retaining clip and a routed passive test PCB with
zero native KiCad ERC/DRC/parity issues. Its eight hard parts pass mesh and rigid
motion checks. This is a separate prototype fixture; the full control PCBs and
production button installation remain open, along with spring/contact selection
and the actual fit/force/closure test.
