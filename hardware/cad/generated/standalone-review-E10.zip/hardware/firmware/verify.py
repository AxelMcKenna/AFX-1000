#!/usr/bin/env python3
"""Build both real ARM profiles and run the seven host suites. No flashing."""
import argparse
import datetime
import hashlib
import json
import pathlib
import re
import subprocess
import xml.etree.ElementTree as ET

ROOT=pathlib.Path(__file__).resolve().parents[2]
FIRMWARE=ROOT/'hardware/firmware'
VALIDATION=ROOT/'hardware/validation'
TESTS=['engine','hardware_controls','audio_arena','hardware_wire','connection_mode','relay_feedback','external_converter']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(args):
    result=subprocess.run([str(a) for a in args],cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(' '.join(map(str,args))+'\n'+'\n'.join(result.stdout.splitlines()[-35:]))
    return result.stdout


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--toolchain',type=pathlib.Path,required=True,help='Directory containing arm-none-eabi-g++')
    parser.add_argument('--host-build',type=pathlib.Path,default=ROOT/'build-hardware')
    parser.add_argument('--sdk',type=pathlib.Path,default=ROOT/'build-hardware/libDaisy')
    args=parser.parse_args()
    sdk=args.sdk.resolve();host=args.host_build.resolve();toolchain=args.toolchain.resolve()
    dependency=json.loads((FIRMWARE/'dependencies.json').read_text())
    commit=run(['git','-C',sdk,'rev-parse','HEAD']).strip()
    assert commit==dependency['libDaisy']['commit'],'SDK commit differs from the pinned source'
    assert not run(['git','-C',sdk,'status','--porcelain','--untracked-files=no']).strip(),'SDK tracked source is modified'
    proposal=json.loads((ROOT/'hardware/electronics/converter/interface-plan.json').read_text())
    profile=json.loads((FIRMWARE/'external-profile.json').read_text())
    assert profile['firmware_adapter_implemented'] and not profile['hardware_verified']
    assert profile['codec_address_seven_bit']==proposal['codec']['address_seven_bit']==24
    for key,pin,net in [('permit_pin',29,'MCU_PERMIT'),('latch_feedback_pin',30,'ARMED'),
                        ('codec_run_shared_reset_pin',0,'CODEC_RUN')]:
        assert profile[key]==pin and proposal['module_gpio']['D'+str(pin)]['net']==net
    assert profile['sample_rate_hz']==proposal['sai']['sample_rate_hz']==48000
    assert profile['bits_per_slot']==proposal['sai']['word_bits']==32
    sdk_hashes={}
    for path,expected in proposal['sdk_source_sha256'].items():
        relative=path.split('libDaisy/',1)[1]
        actual=sha(sdk/relative);assert actual==expected,path;sdk_hashes[relative]=actual
    for path in ['src/daisy_seed.cpp','src/hid/audio.cpp','src/sys/system.cpp','src/sys/dma.c',
                 'core/STM32H750IB_sram.lds','Drivers/STM32H7xx_HAL_Driver/Src/stm32h7xx_hal_sai.c']:
        sdk_hashes[path]=sha(sdk/path)
    seed=(sdk/'src/daisy_seed.h').read_text()
    for key,entry in proposal['module_gpio'].items():
        match=re.search(r'constexpr Pin '+key+r'\s*= Pin\(PORT([A-Z]), (\d+)\);',seed)
        assert match and entry['stm32_pin']=='P'+match.group(1)+match.group(2),key
    run(['cmake','-S',ROOT,'-B',host,'-DCMAKE_BUILD_TYPE=Release','-DRMX_BUILD_TESTS=ON'])
    targets=['rmx_tests']+['rmx_'+name+'_tests' for name in TESTS[1:]]
    run(['cmake','--build',host,'--target',*targets,'--parallel','4'])
    junit=VALIDATION/'external-host-tests.xml'
    host_output=run(['ctest','--test-dir',host,'--output-on-failure','-R','^('+'|'.join(TESTS)+')$',
                     '--output-junit',junit])
    cases=ET.parse(junit).getroot().findall('.//testcase')
    assert sorted(case.attrib['name'] for case in cases)==sorted(TESTS)
    assert not any(case.find('failure') is not None or case.find('skipped') is not None for case in cases)
    direct=run([host/'rmx_external_converter_tests']).strip()
    profiles={}
    for profile,target,build in [('external','rmx_standalone_external','build-external'),('onboard','rmx_standalone','build')]:
        output=run(['make','-C',FIRMWARE,'PROFILE='+profile,'-j4','GCC_PATH='+str(toolchain),'LIBDAISY_DIR='+str(sdk)])
        assert not re.search(r'(?:^|\n).*warning:.*',output) or all(
            any(expected in line for expected in ['not implemented','RWX permissions'])
            for line in output.splitlines() if 'warning:' in line),'Unexpected build warning'
        directory=FIRMWARE/build;binary=directory/(target+'.bin');elf=directory/(target+'.elf')
        sections={}
        for line in run([toolchain/'arm-none-eabi-size','-A',elf]).splitlines():
            fields=line.split()
            if len(fields)==3 and fields[0].startswith('.') and fields[1].isdigit(): sections[fields[0]]=int(fields[1])
        assert sections['.sram1_bss']<=32768 and sections['.sdram_bss']==48*1024*1024
        assert sections['.bss']+sections['.data']<128*1024
        symbols=run([toolchain/'arm-none-eabi-nm','-C',elf])
        assert ('rmx::embedded::ExternalAudio::dispatch(' in symbols)==(profile=='external')
        if profile=='external':
            # Confirm uncached DMA region and 32-byte alignment in actual ELF.
            dma_symbols={}
            for line in symbols.splitlines():
                if 'anonymous namespace)::receive' in line or 'anonymous namespace)::transmit' in line:
                    address=int(line.split()[0],16);assert 0x30000000<=address<0x30008000 and address%32==0
                    dma_symbols[line.split()[-1]]=hex(address)
            assert len(dma_symbols)==2
        else: dma_symbols={}
        profiles[profile]=dict(binary=str(binary.relative_to(ROOT)),binary_bytes=binary.stat().st_size,
            binary_sha256=sha(binary),elf_sha256=sha(elf),sections_bytes=sections,dma_symbols=dma_symbols,
            cross_compiled=True,flashed=False,hardware_verified=False)
    assert profiles['external']['binary_sha256']!=profiles['onboard']['binary_sha256']
    invalid=subprocess.run(['make','-C',str(FIRMWARE),'PROFILE=invalid'],capture_output=True,text=True)
    assert invalid.returncode and 'PROFILE must be onboard or external' in invalid.stderr
    sources=[p for p in FIRMWARE.iterdir() if p.is_file() and p.suffix in ('.h','.cpp','.py','.json','.md')]
    sources+=[FIRMWARE/'Makefile',ROOT/'CMakeLists.txt',ROOT/'src/core/Engine.cpp',ROOT/'tests/external_converter_tests.cpp',
              ROOT/'hardware/electronics/converter/interface-plan.json',ROOT/'hardware/electronics/converter/dependencies.json']
    sources+=sorted((ROOT/'include/rmx').glob('*.h'))
    report=dict(revision='F01',checked_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='Both ARM profiles and seven host suites; no CAD/electronics revalidation or physical test',
        libdaisy_commit=commit,sdk_source_sha256=sdk_hashes,
        toolchain=run([toolchain/'arm-none-eabi-g++','--version']).splitlines()[0],
        profiles=profiles,host_tests=dict(passed=len(cases),failed=0,names=TESTS,junit_sha256=sha(junit)),
        external_test_summary=direct,invalid_profile_rejected=True,
        source_sha256={str(p.relative_to(ROOT)):sha(p) for p in sorted(set(sources))},
        limitations=['Codec and MCU SAI32 mode not tested on hardware','Master clock/BCLK/WS/data edge phase unmeasured',
            'DMA phase/16-word copy reserve and interrupt timing require physical measurement',
            'No ADC input stage, complete power/rail monitors, integrated PCB or complete enclosure placement',
            'Rear/status expander needs receiving-end ANALOG_OK pull-down on future control PCB',
            'Raw converter scale, gain/calibration, noise/THD, latency, bypass transients and soak unverified',
            'microSD sample/preset loader and user settings application incomplete',
            'Existing SDK/newlib unsupported POSIX syscall and RWX linker warnings remain'])
    path=VALIDATION/'external-firmware.json';path.write_text(json.dumps(report,indent=2)+'\n')
    print(direct)
    print('Both ARM profiles build; seven host suites pass; report:',path.relative_to(ROOT))
    for name,profile in profiles.items(): print(name,profile['binary_bytes'],'bytes; DMA SRAM',profile['sections_bytes']['.sram1_bss'])


if __name__=='__main__': main()
