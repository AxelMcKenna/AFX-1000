# Standalone verification record

The [build record](build.json) captures source hashes, the firmware binary hash,
ARM section sizes and six passing host suites. The [memory profile](host-memory.json)
records engine/factory-bank heap payload at 48 and 96 kHz. These are host/build
checks, not physical unit tests.

| Check | Evidence | Scope / limit |
| --- | --- | --- |
| Existing DSP | CTest `engine` | Rates, finite output, allocations and existing control checks |
| Physical controls | CTest `hardware_controls` | Scene/source actions, nudge, bank, release, selected-pad rolls, Hold, long presses and feedback |
| External arena | CTest `audio_arena` | Alignment, reuse, payload preservation, free/coalescing and exhaustion |
| Wire mapping | CTest `hardware_wire` | LED bit order, lever wrap/direction and touch centroid |
| Connection gain switching | CTest `connection_mode` | Immediate bypass request, debounce, dry wait, gain settling, bounce, delayed polling and timer wrap |
| Hardware latch feedback | CTest `relay_feedback` | Initial arming, lost feedback, stable rearm after bypass, switch-pole delay, deliberate bypass and timer wrap |
| Circuit constraints | [E01 calculation record](../electronics/generated/line-levels.json) and [fault-latch scenarios](../electronics/generated/bypass-logic.json) | Ideal headroom/logic calculations; no electrical, SPICE, ERC or bench evidence |
| Embedded application | ARM ELF/bin and sections in `build.json` | Cross-compiles with pinned actual SDK; not run on Seed3 |
| Mechanical solids | [CAD report](../cad/generated/solid-validation.json) | Seven closed, consistently wound, connected positive-volume STL parts |
| Lever motion | Same CAD report | Expanded convex sweep through 0-35 degrees; excludes spring/fasteners/wiring |
| Internal placement | [Reserve check](../cad/generated/internal-clearance.json) | Named conservative boxes and mounts, including actual E07 output-board positions; no physical wire-fit evidence |
| B01 button hard parts | [Button mesh/motion report](../cad/generated/button-solid-validation.json) | Eight connected closed solids; continuous rigid travel against guide/panel; excludes compliant contacts, spring and printed fit |
| B01 passive test PCB | [Native KiCad record](../electronics/button_test/generated/verification.json) | Zero ERC/DRC/unconnected/parity issues and checked exported pin pairs; not the full control PCB |
| E02 watchdog/driver schematic | [Native record](../electronics/bypass/generated/verification.json) | Zero ERC issues, package-pin contract and 25 exported-netlist ideal fault scenarios; no PCB/bench proof |
| E03 stereo bypass contacts | [Native record](../electronics/audio_bypass/generated/verification.json) | Zero ERC, exact exported pin nets, four settled relay combinations, fresh E02 coil-interface check and nominal relay land-pattern audit; no PCB/bench proof |
| E04 audio architecture | [Noise/gain/supply screen](../electronics/generated/audio-budget.json) | Rejects approval of the prototype converter/E01 network under stated assumptions; external codec and ±19 V driver candidates still need circuits, firmware and physical measurements |
| E05 post-receiver output stage | [Native record](../electronics/output_stage/generated/verification.json) and [circuit analysis](../electronics/output_stage/generated/circuit-analysis.json) | Zero ERC, exact pins/interfaces, 12 ideal AC/four ideal DC cases, 256 tolerance cases and conditional power/noise/voltage screens; routing checked separately under E07; full analog circuit and bench work incomplete |
| E07 routed output board | [Routing record](../electronics/output_stage/generated/routing-verification.json) | 41 actual footprints, four mounting holes, 211 segments, 45 vias and saved AGND fill; zero all-severity DRC/library/parity issues and zero open connections; final stackup/parts and physical audio open |
| E08 DAC I/V / receiver | [Native record](../electronics/dac_receiver/generated/verification.json) and [circuit analysis](../electronics/dac_receiver/generated/circuit-analysis.json) | 60 exact component contracts, zero ERC, fresh E05 load/interface, 24 ideal AC and 32 DC cases, 16,384 listed passive/source corners and 12 ideal output-cascade cases; hypothetical DAC normalization, no complete codec, PCB/placement or physical audio proof |
| A03 output-board fit | [CAD report](../cad/generated/solid-validation.json) and [reserve report](../cad/generated/internal-clearance.json) | Seven checked solids; empty modeled output/base/control/lead/scene-PCB intersection, 170 nonintersecting named reserves and lever sweep; conditional dimensions/assembly, no physical fit or complete electronics placement |

The firmware reserves 48 MiB of SDRAM. Linked code and internal static data fit
the SDK regions; processor timing, stack high-water marks, interrupt behavior and
physical memory stability remain unmeasured. The firmware guide records the
SDK/newlib syscall and SRAM linker warnings.

Open gates include PCB design/assembly, physical control fit, sensor calibration,
LED optics, boot/power behavior, watchdog/bypass operation, round-trip latency,
gain/headroom, noise/distortion, thermal behavior and a two-hour hardware soak.
Sample/preset storage and user settings application still need implementation.
