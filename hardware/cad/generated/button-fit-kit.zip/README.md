B01 button fit prototype

Read hardware/cad/BUTTON-FIT.md for parts, open spring/contact selections, assembly and measurements.
The test PCB has zero native KiCad issues; the kit has not been printed or assembled.
This archive is a separate test fixture, not the complete standalone RMX hardware.
